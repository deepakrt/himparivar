import React, { Component, useState, useEffect } from "react";
import Header from "../components/Header";
import HeaderBar from "../components/HeaderBar";
import LMenu from "../components/LMenu";
import Footer from "../components/Footer";
import Editshoplist from "../components/Models/Editshoplist";
import Logout from "../components/Logout";
import { useParams } from "react-router-dom";
import { useNavigate } from "react-router-dom";

const AddnewFamily = () => {
  const [searchCardData, setSearchCardData] = useState("");
  const [inputValue, setInputValue] = useState("");
  const [error, setError] = useState("");
  const [errorstyle, setErrorstyle] = useState(
    "form-control bg-light border-1 small"
  );
  const { fm } = useParams();
  const navigate = useNavigate();

  const loggedUser = JSON.parse(localStorage.getItem("loggedUser"));
  var authToken = loggedUser.data.token;

  const handleChange = (event) => {
    const value = event.target.value;
    setErrorstyle("form-control bg-light border-1 small");
    setInputValue(value);
    setError("");
    handleSubmit(event);
  };

  const handleSubmit = (event) => {
    event.preventDefault();

    if (inputValue.trim() === "") {
      setError("Input cannot be blank.");
    } else {
      // Perform your action or validation logic here
      console.log("Input value:", inputValue);
      setError("");
    }

    var srchCardNo = document.getElementById("srchCardNo").value;

    if (inputValue.trim() === "") {
      setError("Ration Card No is Empty. Try again!");
      setErrorstyle("form-control bg-light border-1 small error-border-wrn");
      return false;
    } else {
      // Perform your action or validation logic here
      setError("Enter Ration Card No.");
      setErrorstyle("form-control bg-light border-1 small");
    }

    //FETCH DATA FROM API
    const apiUrlWardshop =
      "urban-dept/fetch-ration-details?rationCardNo=" + srchCardNo;
    const requestOptions = {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        Authorization: "Bearer " + authToken,
      },
    };

    //let apiWardMembersData = FetchApiCall(apiUrlWardshop, requestOptions);
    fetch(apiUrlWardshop, requestOptions)
      .then((response) => {
        console.log(response);

        if (response.status == "500") {
          setErrorstyle(
            "form-control bg-light border-1 small error-border-wrn"
          );
        }

        if (!response.ok) {
          throw new Error("Network response was not ok");
        }

        return response.json();
      })
      .then((data) => {
        if (data.status === "OK") {
          setSearchCardData(data);
          //return data;
        } else {
          console.log("Request is not successful!");
        }
      })
      .catch((error) => {
        console.error("Error:", error);
      }, []);
  };

  const navLink = (props) => {
    navigate(props);
  };


  const [isChecked, setIsChecked] = useState(false);
  const [items, setItems] = useState(searchCardData.data);
  const [itemslist, setItemslist] = useState(searchCardData.data);
  const [selectedItems, setSelectedItems] = useState([]);


 


  const handleCheckboxChange = (event) => {
    const checkboxId = event.target.value;  

    //alert(document.getElementById("selmember-"+checkboxId).value);
    if (event.target.checked) {
      setSelectedItems((prevCheckedIds) => [...prevCheckedIds, checkboxId]);
    } else {
      setSelectedItems((prevCheckedIds) =>
        prevCheckedIds.filter((id) => id !== checkboxId)
      );
    }
  };

  const getSelectedMembers=(selectedItems)=>{
    localStorage.setItem('setSelectedItems',selectedItems);
    navigate('/selmembers');

    const lstoreSelectedItems = localStorage.getItem("setSelectedItems");
    //console.log("get storage:"+lstoreSelectedItems);

  }

 
 


  return (
    <>
      <div id="wrapper">
        {/* <!-- Left Menu Bar --> */}
        <LMenu />
        {/* <!-- Left Menu Bar End --> */}
        {/* <!-- Content Wrapper --> */}
        <div id="content-wrapper" className="d-flex flex-column">
          {/* <!-- Page Wrapper --> */}

          {/* <!-- Header Content --> */}
          <div id="content">
            {/* <!-- Begin Page Content --> */}
            {/* <!-- Head Search Bar --> */}
            <Header />
            {/* <!-- Head Search Bar End --> */}
            {/* <!-- Begin Page Content --> */}
            <div className="container-fluid">
              {/* <!-- Page Heading --> */}
              <HeaderBar titlePage={"Add New Parivar"} />
              {/* <!-- End of Header Content --> */}

              <div className="card shadow mb-4">
                <div className="card-header py-3">
                  {
                    // searchCardData ? alert(searchCardData.data[0].memberName): alert("not def")
                  }
                  <form
                    name="frmRCsearch"
                    className="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search"
                    style={{ width: "35%" }}
                  >
                    <div className="input-group">
                      <input
                        type="text"
                        name="srchCardNo"
                        id="srchCardNo"
                        className={errorstyle}
                        placeholder={error}
                        aria-label="Search"
                        aria-describedby="basic-addon2"
                        value={inputValue}
                        onChange={handleChange}
                        onfocus={handleChange}
                      />
                      <div className="input-group-append">
                        <button
                          className="btn btn-primary"
                          type="button"
                          onClick={handleSubmit}
                        >
                          <i className="fas fa-search fa-sm"></i>
                        </button>
                      </div>
                      {/* {error && <div style={{ color: 'red' }}>{error}</div>} */}
                    </div>
                  </form>
                </div>

                {/* Data Table Start */}

                <div className="card-body">
                  <div className="table-responsive">
                    <table
                      className="table table-bordered"
                      id="dataTable1"
                      width="100%"
                      cellSpacing="0"
                    >
                      <thead>
                        <tr>
                          <th>Select</th>
                          <th>Ration Card No</th>
                          <th>Card Type</th>
                          <th>Name</th>
                          <th>Relation</th>
                          <th>Block</th>
                          <th>eKYC Status</th>
                        </tr>
                      </thead>

                      <tbody>
                        {searchCardData.data ? (
                          searchCardData.data.map((item, index) => (
                            // <li key={index}>{item}</li>
                            
                            <tr>
                              <td>
                               {console.log(selectedItems)}
                               {console.log(item.aadhaarNumber)}
                                <input
                                  type="checkbox"
                                  value={item.aadhaarNumber}
                                  id={`checkbox-${item.aadhaarNumber}`}
                                  checked={selectedItems.includes(item.aadhaarNumber)}
                                  onChange={handleCheckboxChange}
                                />
                               {/* <input type="text" id={`selmember-${item.aadhaarNumber}`} name="smembers" value={item} /> */}
                              </td>
                             
                              <td>{item.rationCardNumber}</td>
                              <td>{item.cardType}</td>
                              <td>{item.memberName}</td>
                              <td>{item.relationName}</td>
                              <td>{item.block}</td>
                              <td>{item.ekycStatus}</td>
                            </tr>
                          ))
                        ) : (
                          <tr>
                            <td colSpan={7}> Records are not available. </td>
                          </tr>
                        )}

                        {searchCardData.data ? (
                          // <li key={index}>{item}</li>
                          <tr>
                            <td colSpan={7}>
                              <div align="right">
                                <a
                                  className="btn btn-primary btn-icon-split"
                                  href="javascript:void(0);"
                                  // onClick={() => selectedMembers()}
                                >
                                  <span class="icon text-white-50">
                                    <i class="fas fa-arrow-right"></i>
                                  </span>
                                  <span class="text" onClick={() => getSelectedMembers(selectedItems)} >Next</span>
                                </a>
                              </div>
                            </td>
                          </tr>
                        ) : (
                          <>{/* No Button */}</>
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
              {/* End Data Table*/}
            </div>
          </div>
          {/* <!-- Footer Section --> */}
          <Footer />
          {/* <!-- Footer Section End --> */}
          {/* <!-- End of Page Wrapper --> */}

          {/* <!-- Scroll to Top Button--> */}
          <a className="scroll-to-top rounded" href="#page-top">
            <i className="fas fa-angle-up"></i>
          </a>

          {/* <!-- Logout Modal--> */}
          <Logout />
          {/* <!-- Edit Shop Modal--> */}
          <Editshoplist datashop="deee" />
        </div>
        {/* <!-- Content-Wrapper End--> */}
      </div>
    </>
  );
};

export default AddnewFamily;
