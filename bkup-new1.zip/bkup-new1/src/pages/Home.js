import React,{Component} from 'react';



class Home extends Component {

	render(){
		return(

			<div className="align-items-center">
				Home Page
			</div>
		)
	}

}




export default Home;