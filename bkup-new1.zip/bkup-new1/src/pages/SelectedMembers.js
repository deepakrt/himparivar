import React, { Component, useState, useEffect } from "react";
import Header from "../components/Header";
import HeaderBar from "../components/HeaderBar";
import LMenu from "../components/LMenu";
import Footer from "../components/Footer";
import Editshoplist from "../components/Models/Editshoplist";
import Logout from "../components/Logout";
import { useParams } from 'react-router-dom';
import { useNavigate } from "react-router-dom";



class SelectedMembers extends Component {

	render(){
		return(

			<>
			<div id="wrapper">
        {/* <!-- Left Menu Bar --> */}
        <LMenu />
        {/* <!-- Left Menu Bar End --> */}
        {/* <!-- Content Wrapper --> */}
        <div id="content-wrapper" className="d-flex flex-column">
          {/* <!-- Page Wrapper --> */}

          {/* <!-- Header Content --> */}
          <div id="content">
            {/* <!-- Begin Page Content --> */}
            {/* <!-- Head Search Bar --> */}
            <Header />
            {/* <!-- Head Search Bar End --> */}
            {/* <!-- Begin Page Content --> */}
            <div className="container-fluid">
              {/* <!-- Page Heading --> */}
              <HeaderBar titlePage={"Selected Parivar Member"} />
              {/* <!-- End of Header Content --> */}

              <div className="card shadow mb-4">
                <div className="card-header py-3">
                
                 
                </div>

                {/* Data Table Start */}

                <div className="card-body">
                  <div className="table-responsive">
                   
                  </div>
                </div>
              </div>
              {/* End Data Table*/}
            </div>
          </div>
          {/* <!-- Footer Section --> */}
          <Footer />
          {/* <!-- Footer Section End --> */}
          {/* <!-- End of Page Wrapper --> */}

          {/* <!-- Scroll to Top Button--> */}
          <a className="scroll-to-top rounded" href="#page-top">
            <i className="fas fa-angle-up"></i>
          </a>

          {/* <!-- Logout Modal--> */}
          <Logout />
          {/* <!-- Edit Shop Modal--> */}
          <Editshoplist datashop="deee" />
        </div>
        {/* <!-- Content-Wrapper End--> */}
      </div>
			</>
		)
	}

}




export default SelectedMembers;