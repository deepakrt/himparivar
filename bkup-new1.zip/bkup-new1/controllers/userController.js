exports.userController = (req,res)=>{
    res.json({
         usersList:["user 1333","us6666666er 2"]
    });
}