import React,{Component} from 'react';



class NoPage extends Component {

	render(){
		return(

			<div className="align-items-center">
				No Page found
			</div>
		)
	}

}




export default NoPage;