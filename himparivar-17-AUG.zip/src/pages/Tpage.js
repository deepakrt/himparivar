import React  from 'react';
import { DatePicker, LocalizationProvider } from "@mui/x-date-pickers";
import dayjs from "dayjs";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";

const Tpage = () => {
  return (
    <div>
      <h2>Beautiful Date Picker</h2>

      <LocalizationProvider dateAdapter={AdapterDayjs}>
        <DatePicker defaultValue={dayjs("2022-04-17")} />
      </LocalizationProvider>
    </div>
  );
};

export default Tpage;
