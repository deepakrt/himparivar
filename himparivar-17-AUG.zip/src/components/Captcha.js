import "bootstrap/dist/css/bootstrap.min.css";
import captchaImg from "./captcha.jpg";
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
//import axios from "axios";

function Captcha() {
  const [user, setUser] = useState({});

  const characters = "abc123";
  function generateString(length) {
    let result = "";
    const charactersLength = characters.length;
    for (let i = 0; i < length; i++) {
      result += characters.charAt(Math.floor(Math.random() * charactersLength));
    }
    return result;
  }

  const captcha = generateString(6); // Function called here and save in captcha variable
  const navigate = useNavigate();
  let handleChange = (e) => {
    let name = e.target.name;
    let value = e.target.value;

    setUser(user);
  };

  const onSubmit = (e) => {

    var element = document.getElementById("succesBTN");
    var inputData = document.getElementById("inputType").value;
    var username = document.getElementById("username").value;
    var password = document.getElementById("password").value;

    var clickButton = document.getElementById("buttonClick");
    clickButton.style.className = "disable-button";
    if (username == "") {
      document.getElementById("username").style = "border:1px solid #E83E8C";
      document.getElementById("username").focus();
      return false;
    }else{
      document.getElementById("username").style = "border:1px solid #d1d3e2";
    }
    if (password == "") {
      document.getElementById("password").style = "border:1px solid #E83E8C";
      document.getElementById("password").focus();
      return false;
    }else{
      document.getElementById("username").style = "border:1px solid #d1d3e2";
    }

    let result;
    // element.style.display="none";
    element.innerHTML = "Checking...";
    clickButton.innerHTML = "In Process...";

    var myFunctions = function () {
      if (captcha == inputData) {
        element.innerHTML = "";
        element.style.display = "none";

        // send the username and password to the server by API

        //##########################################################################
        // URL of the REST API endpoint where you want to create a new resource
        const apiUrl = "urban-dept/login"; // Replace this with your actual API endpoint

        // Request options for the fetch function
        const requestOptions = {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            // Add any other headers required by your API, e.g., authentication tokens, etc.
          },
          body: JSON.stringify({ username, password }),
        };

        // Use fetch to make the POST request
        fetch(apiUrl, requestOptions)
          .then((response) => {
           
            if (!response.ok) {
              // Handle error responses (non-2xx status codes)
              throw new Error("Network response was not ok");
            }
            // If the response is successful, parse the JSON data from the response
            return response.json();
          })
          .then((data) => {
            // Handle the data returned from the server after successful creation
            
            if(data.status==="OK"){
                // set the state of the user
                setUser(data)
                // store the user in localStorage
                localStorage.setItem('loggedUser',JSON.stringify(data));
                // Refresh some localstage variable 
                localStorage.removeItem("FamilyrelDetails");
                //---------------------------------

                navigate("/dashboard");
            }else{
                element.style.display = "inline";
                element.innerHTML = "The user/password are wrong. Please try again.";
                clickButton.innerHTML = "Login";
            }
            // console.log("New user created:", data);
            // You can add any further logic here based on the response from the server
          })
          .catch((error) => {
            // Handle any errors that occurred during the fetch process
            console.error("Error:", error);
            element.style.display = "inline";
            element.innerHTML = "The user/password are wrong. Please try again.";
            clickButton.innerHTML = "Login";
          });

        //END API

        
      } else {
        element.style.display = "inline";
        element.innerHTML = "Captcha not matched!";
        clickButton.innerHTML = "Login";
        var myFunction = function () {};
        setTimeout(myFunction, 1000);
      }
    };
    setTimeout(myFunctions, 1000);
  };

  return (
    <div className="container">
      <div className="form-group row">
        <div className="col-sm-6">
          <img src={captchaImg} className="mt-3 mb-3" height="50" />
          <h5
            id="captcha"
            style={{
              marginTop: "-54px",
              marginLeft: "38px",
              position: "absolute",
            }}
          >
            {captcha}
          </h5>
        </div>
        <div className="col-sm-6">
          <input
            type="text"
            id="inputType"
            className="form-control"
            placeholder="Enter Captcha"
            onChange={handleChange}
            autoComplete="off"
            style={{ marginTop: "13px" }}
          />
        </div>
        <span
          className="form-group row alert alert-danger"
          role="alert"
          id="succesBTN"
          style={{
            display: "none",
            padding: "4px",
            textAlign: "center",
            marginLeft: "2px",
          }}
        ></span>
      </div>
      <div className="col-md-8">
        <div className="form-group row">
          <button
            type="button"
            id="buttonClick"
            onClick={onSubmit}
            className="btn btn-primary ml-1"
          >
            Login
          </button>
        </div>
      </div>
    </div>
  );
}
export default Captcha;
