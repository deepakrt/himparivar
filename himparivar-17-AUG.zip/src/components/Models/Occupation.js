import React, { useState, useEffect } from "react";
import "../Models/Editmembers.css";
import { useNavigate } from "react-router-dom";
const Occupation = (props) => {

  const arrDT = props.OnOccupationDetails;
  const [selectedOptions, setSelectedOptions] = useState({});
  const [selectedOptionsOccu, setSelectedOptionsOccu] = useState({});

  const loggedUser = JSON.parse(localStorage.getItem("loggedUser"));
  var authToken = loggedUser.data.token;

  const handleSelectChange = (event, memberName) => {
    const newSelectedOptions = { ...selectedOptions };
    newSelectedOptions[memberName] = event.target.value;
    setSelectedOptions(newSelectedOptions);
  };
  useEffect(() => {
    //GET LIST FOR Occupation OPTION
  const requestOptions = {
    method: "GET",
    headers: {
      "Content-Type": "application/json",
      Authorization: "Bearer " + authToken,
    },
  };
  const apiUrlMunci = "urban-dept/getOccupations";
  fetch(apiUrlMunci, requestOptions)
    .then((response) => {
      //console.log(response);

      if (response.status == "500") {
        //API ERROR
        console.log("API ERROR 500");
      }

      if (!response.ok) {
        throw new Error("Network response was not ok");
      }

      return response.json();
    })
    .then((data) => {
      if (data.status === "OK") {
        setSelectedOptionsOccu(JSON.parse(JSON.stringify(data)));
        //return data;
      } else {
        console.log("Request is not successful!");
      }
    })
    .catch((error) => {
      console.error("Error:", error);
    }, []);


   // console.log(selectedOptionsRL.data);

  //---------------------------
  }, []);// END OF USeEffect
  

  const updateOccupation = () => {
    props.callCloseAndTickUpdate("tick-occup");
    console.log(selectedOptions);
  };

  return (
    <>
      {/* <!-- Logout Modal--> */}
      <div
        className="modal fade"
        id="occupationdetails"
        tabIndex="-1"
        role="dialog"
        aria-labelledby="exampleModalLabel"
        aria-hidden="true"
      >
        <div className="modal-dialog modal-dialog-shop " role="document">
          <div className="modal-content model-edit-members">
            <div className="modal-header">
              <h5 className="modal-title" id="exampleModalLabel">
                Occupation Details
              </h5>
              <button
                className="close"
                type="button"
                data-dismiss="modal"
                aria-label="Close"
              >
                <span aria-hidden="true">×</span>
              </button>
            </div>
            <div className="modal-body">
             {/* START DATA  TABLE */}
             {/* <!-- DataTales Example --> */}
                    <div className="card shadow mb-4">
                        <div className="card-header py-3">
                            <h6 className="m-0 font-weight-bold text-primary">
                            Update Occupation
                            </h6>
                        </div>
                        <div className="card-body">
                        <div className="table-responsive">
                    <table style={{ display: "" }}>
                      {arrDT ? (
                        arrDT.map((item, index) => (
                          <>
                            <tr>
                              <td>{item.memberName}</td>
                              <td>
                                <select
                                  key={index}
                                  name={"sel-frel-" + index}
                                  id={"sel-frel-" + index}
                                  value={selectedOptions[item.memberName] || ""}
                                  onChange={(event) =>
                                    handleSelectChange(event, item.memberName)
                                  }
                                >
                                  {selectedOptionsOccu.data ? (
                                   
                                   selectedOptionsOccu.data.map((item, index) => 
                                    <>
                                     <option value={item.id}>{item.professionName}</option>
                                    </>)
                                  ) : (
                                    <> <option value="">Select an option</option></>
                                  )}
                                 
                                  
                                </select>
                              </td>
                            </tr>
                          </>
                        ))
                      ) : (
                        <></>
                      )}
                    </table>
                  </div>
                        </div>
                    </div>
              {/* DATA END TABLE */}
            </div>
            <div className="modal-footer">
              <button
                className="btn btn-secondary"
                type="button"
                data-dismiss="modal"
              >
                Cancel
              </button>
              <a
                className="btn btn-primary update-btn"
                type="button"
                data-dismiss="modal"
                aria-label="Close"
                onClick={updateOccupation}
              >
                <span aria-hidden="true">Update</span>
              </a>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Occupation;
