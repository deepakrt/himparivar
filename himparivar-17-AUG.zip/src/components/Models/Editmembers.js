import React, { useState, useRef, useEffect } from "react";
import "../Models/Editmembers.css";
const Editmembers = (props) => {
  const [selectedOptionsnames, setSelectedOptionsnames] = useState("");
  const [selectedOptionsEC, setSelectedOptionsEC] = useState({});
  const [selectedOptionsRL, setSelectedOptionsRL] = useState({});
  const [selectedOptionsSC, setSelectedOptionsSC] = useState({});
  const [selectedOptionsRes, setSelectedOptionsRes] = useState({});
  const [selectedOptionsDist, setSelectedOptionsDist] = useState({});
  const [selectedOptionsMunci, setSelectedOptionsMunci] = useState({});
  const [selectedOptionsMunciVal, setSelectedOptionsMunciVal] = useState({});
  const [selectedOptionsWard, setSelectedOptionsWard] = useState({});
  const [selectedOptionsWardVal, setSelectedOptionsWardVal] = useState({});
  const inputRef = useRef(null);
  const [errStyle, setErrStyle] = useState("");

  const arrDT = props.OnEditMemberDetails;
  // const arrEC = props.arrSelectedOptionsEc;
  const arrEC2 = JSON.parse(JSON.stringify(props.arrSelectedOptionsEc));
  const arrRL = JSON.parse(JSON.stringify(props.arrSelectedOptionsRL));
  const arrSC = JSON.parse(JSON.stringify(props.arrSelectedOptionsSC));
  const arrRes = JSON.parse(JSON.stringify(props.arrSelectedOptionsRes));
  const arrDist = JSON.parse(JSON.stringify(props.arrSelectedOptionsDist));
  const arrMunci = JSON.parse(JSON.stringify(props.arrSelectedOptionsMunci));
  const loggedUser = JSON.parse(localStorage.getItem("loggedUser"));
  var authToken = loggedUser.data.token;
  const [selectedOptions, setSelectedOptions] = useState({});
  const [newSelectedOptions, setNewSelectedOptions] = useState([]);
  const [FamilyrelDetails, setFamilyrelDetails] = useState([]);
  // console.log(arrDist);

  // SELECT NAME FOR HoF
  const handleSelectChangeNames = (event) => {
    var selVal = event.target.value;
    setSelectedOptionsnames(selVal);
  };
  // SELECT EC
  const handleSelectEC = (event) => {
    setSelectedOptionsEC(event.target.value);
  };

  // SELECT RL
  const handleSelectRL = (event) => {
    setSelectedOptionsRL(event.target.value);
  };
  // SELECT SC
  const handleSelectSC = (event) => {
    setSelectedOptionsSC(event.target.value);
  };
  // SELECT RES
  const handleSelectRes = (event) => {
    setSelectedOptionsRes(event.target.value);
  };

  //---------------------------

  // SELECT Dist
  const handleSelectDist = (event) => {
    const DistStr = event.target.value;
    const DistCode = DistStr.split("#");

    //GET LIST FOR MUNCI FROM API
    const requestOptions = {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        Authorization: "Bearer " + authToken,
      },
    };
    const apiUrlMunci =
      "urban-dept/getMunicipalities?districtCode=" + DistCode[0];
    fetch(apiUrlMunci, requestOptions)
      .then((response) => {
        // console.log(response);

        if (response.status == "500") {
          //API ERROR
          console.log("API ERROR 500");
        }

        if (!response.ok) {
          throw new Error("Network response was not ok");
        }

        return response.json();
      })
      .then((data) => {
        if (data.status === "OK") {
          setSelectedOptionsMunci(JSON.parse(JSON.stringify(data)));
          //return data;
        } else {
          console.log("Request is not successful!");
        }
      })
      .catch((error) => {
        console.error("Error:", error);
      }, []);
    //---------------------------

    setSelectedOptionsDist(event.target.value);
  };
  // SELECT Munci
  const handleSelectMunci = (event) => {
    const MunciStr = event.target.value;
    const MunciID = MunciStr.split("#");

    //GET LIST FOR WARDS FROM API
    const requestOptions = {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        Authorization: "Bearer " + authToken,
      },
    };
    const apiUrlMunci = "urban-dept/getWards?municipalId=" + MunciID[0];
    fetch(apiUrlMunci, requestOptions)
      .then((response) => {
        // console.log(response);

        if (response.status == "500") {
          //API ERROR
          console.log("API ERROR 500");
        }

        if (!response.ok) {
          throw new Error("Network response was not ok");
        }

        return response.json();
      })
      .then((data) => {
        if (data.status === "OK") {
          setSelectedOptionsWard(JSON.parse(JSON.stringify(data)));
          //return data;
        } else {
          console.log("Request is not successful!");
        }
      })
      .catch((error) => {
        console.error("Error:", error);
      }, []);
    //---------------------------
    setSelectedOptionsMunciVal(event.target.value);
  };
  // SELECT Ward
  const handleSelectWard = (event) => {
    setSelectedOptionsWardVal(event.target.value);
  };

  // Address
  const [textAddressValue, setTextAddressValue] = useState("");

  const handleTextAddChange = (event) => {
    setTextAddressValue(event.target.value);
  };
  const explodedArray = (str) => {
    var arrs = [];
    if (typeof str === "string") {
      if (str.length === 0) {
        //alert("blnk")
        return false;
      } else {
        var arrs = str.split("#");
      }
    } else {
    }
    return arrs;
  };

  const updateFmaily = () => {
    setFamilyrelDetails([]);
    var selVal = JSON.parse(JSON.stringify(selectedOptionsnames));
    const arrFm = explodedArray(
      JSON.parse(JSON.stringify(selectedOptionsnames))
    );
    const arrEL = explodedArray(JSON.parse(JSON.stringify(selectedOptionsEC)));
    const arrRL = explodedArray(JSON.parse(JSON.stringify(selectedOptionsRL)));
    const arrSC = explodedArray(JSON.parse(JSON.stringify(selectedOptionsSC)));
    const arrRes = explodedArray(JSON.parse(JSON.stringify(selectedOptionsRes)));
    const arrDist = explodedArray(JSON.parse(JSON.stringify(selectedOptionsDist)));
    const arrMunci = explodedArray(JSON.parse(JSON.stringify(selectedOptionsMunciVal)));
    const arrWard = explodedArray(JSON.parse(JSON.stringify(selectedOptionsWardVal)));

    FamilyrelDetails.push({
      family: {
        headOfFamilyId: arrFm[1],
        headOfFamilyName: arrFm[0],
        economicLevelId: arrEL[0],
        economicLevelName: arrEL[1],
        ReligionId: arrRL[0],
        ReligionName: arrRL[1],
        socialCategoryId: arrSC[0],
        socialCategoryName: arrSC[1],
        residentailStatusId: arrRes[0],
        residentailStatusName: arrRes[1],
        districtId: arrDist[0],
        districtName: arrDist[1],
        MunicipalityId: arrMunci[0],
        MunicipalityName: arrMunci[1],
        wardId: arrWard[0],
        wardName: arrWard[1],
      },
    });

    localStorage.setItem("FamilyrelDetails",JSON.stringify(FamilyrelDetails[0]));

   ///console.log(JSON.parse(JSON.stringify(FamilyrelDetails)));
    props.callCloseAndTickUpdate("family-d");
  };

  return (
    <>
      {/* <!-- Logout Modal--> */}
      <div
        className="modal fade"
        id="editmembers"
        tabIndex="-1"
        role="dialog"
        aria-labelledby="exampleModalLabel"
        aria-hidden="true"
      >
        <div className="modal-dialog modal-dialog-shop " role="document">
          <div className="modal-content model-edit-members">
            <div className="modal-header">
              <h5 className="modal-title" id="exampleModalLabel">
                Family Details
              </h5>
              <button
                className="close"
                type="button"
                data-dismiss="modal"
                aria-label="Close"
              >
                <span aria-hidden="true">×</span>
              </button>
            </div>
            <div className="modal-body">
              {/* START DATA  TABLE */}
              {/* <!-- DataTales Example --> */}
              <div className="card shadow mb-4">
                <div className="card-header py-3">
                  <h6 className="m-0 font-weight-bold text-primary">
                    Update Family Details
                  </h6>
                </div>
                <div className="card-body">
                  <div className="table-container">
                    <div className="table-row">
                      <div className="header table-cell">Head of Family</div>
                      <div className="table-cell">
                        <select
                          name="hof-name"
                          id="hof-name"
                          value={selectedOptionsnames}
                          onChange={(event) => handleSelectChangeNames(event)}
                          ref={inputRef}
                          required
                          style={{ border: errStyle }}
                        >
                          <option value="">Select an option</option>
                          {arrDT ? (
                            arrDT.map((item, index) => (
                              <>
                                <option
                                  value={
                                    item.memberName + "#" + item.aadhaarNumber
                                  }
                                >
                                  {item.memberName}
                                </option>
                              </>
                            ))
                          ) : (
                            <>
                              <option value="" required>
                                Select an option
                              </option>
                            </>
                          )}
                        </select>
                      </div>
                    </div>
                    <div className="table-row">
                      <div className="header table-cell">Economic Level</div>
                      <div className="table-cell">
                        <select
                          name="economic-level"
                          id="economic-level"
                          value={selectedOptionsEC}
                          onChange={handleSelectEC}
                          required
                        >
                          <option value="">Select an option</option>
                          {arrEC2.data ? (
                            arrEC2.data.map((item, index) => (
                              <>
                                <option
                                  value={item.id + "#" + item.economicStatus}
                                >
                                  {item.economicStatus}
                                </option>
                              </>
                            ))
                          ) : (
                            <>
                              <option value="_#_">Select an option</option>
                            </>
                          )}
                        </select>
                      </div>
                    </div>
                    <div className="table-row">
                      <div className="header table-cell">Religion</div>
                      <div className="table-cell">
                        <select
                          name="religions"
                          id="religions"
                          value={selectedOptionsRL}
                          onChange={handleSelectRL}
                          required
                        >
                          <option value="">Select an option</option>
                          {arrRL.data ? (
                            arrRL.data.map((item, index) => (
                              <>
                                <option
                                  value={item.id + "#" + item.religionName}
                                >
                                  {item.religionName}
                                </option>
                              </>
                            ))
                          ) : (
                            <>
                              <option value="_#_">Select an option</option>
                            </>
                          )}
                        </select>
                      </div>
                    </div>
                    <div className="table-row">
                      <div className="header table-cell">Social Category</div>
                      <div className="table-cell">
                        <select
                          name="social-cat"
                          id="social-cat"
                          value={selectedOptionsSC}
                          onChange={handleSelectSC}
                          required
                        >
                          <option value="">Select an option</option>
                          {arrSC.data ? (
                            arrSC.data.map((item, index) => (
                              <>
                                <option
                                  value={
                                    item.id +
                                    "#" +
                                    item.socialCategoryNameEnglish
                                  }
                                >
                                  {item.socialCategoryNameEnglish}
                                </option>
                              </>
                            ))
                          ) : (
                            <>
                              <option value="">Select an option</option>
                            </>
                          )}
                        </select>
                      </div>
                    </div>
                    <div className="table-row">
                      <div className="header table-cell">Resident Status</div>
                      <div className="table-cell">
                        <select
                          name="resedential-st"
                          id="resedential-st"
                          value={selectedOptionsRes}
                          onChange={handleSelectRes}
                          required
                        >
                          <option value="">Select an option</option>
                          {arrRes.data ? (
                            arrRes.data.map((item, index) => (
                              <>
                                <option
                                  value={item.id + "#" + item.locationName}
                                >
                                  {item.locationName}
                                </option>
                              </>
                            ))
                          ) : (
                            <>
                              <option value="">Select an option</option>
                            </>
                          )}
                        </select>
                      </div>
                    </div>
                    <div className="table-row">
                      <div className="header table-cell">District</div>
                      <div className="table-cell">
                        <select
                          name="dist-lst"
                          id="dist-lst"
                          value={selectedOptionsDist}
                          onChange={handleSelectDist}
                          required
                        >
                          <option value="" selected>
                            Select
                          </option>
                          {arrDist.data ? (
                            arrDist.data.map((item, index) => (
                              <>
                                <option
                                  value={
                                    item.districtCode + "#" + item.districtName
                                  }
                                >
                                  {item.districtName}
                                </option>
                              </>
                            ))
                          ) : (
                            <>
                              <option value="">Select an option</option>
                            </>
                          )}
                        </select>
                      </div>
                    </div>
                    <div className="table-row">
                      <div className="header table-cell">Muncipality</div>
                      <div className="table-cell">
                        <select
                          name="munci-lst"
                          id="munci-lst"
                          value={selectedOptionsMunciVal}
                          onChange={handleSelectMunci}
                          required
                        >
                          <option value="" selected>
                            Select
                          </option>
                          {selectedOptionsMunci.data ? (
                            selectedOptionsMunci.data.map((item, index) => (
                              <>
                                <option
                                  value={
                                    item.municipalId + "#" + item.municipalName
                                  }
                                >
                                  {item.municipalName}
                                </option>
                              </>
                            ))
                          ) : (
                            <>
                              <option value="">Select an option</option>
                            </>
                          )}
                        </select>
                      </div>
                    </div>
                    <div className="table-row">
                      <div className="header table-cell">Ward</div>
                      <div className="table-cell">
                        <select
                          name="munci-lst"
                          id="munci-lst"
                          value={selectedOptionsWardVal}
                          onChange={handleSelectWard}
                          required
                        >
                           <option value="" selected>
                            Select
                          </option>
                          {selectedOptionsWard.data ? (
                            selectedOptionsWard.data.map((item, index) => (
                              <>
                                <option value={item.id + "#" + item.wardName}>
                                  {item.wardNo + " " + item.wardName}
                                </option>
                              </>
                            ))
                          ) : (
                            <>
                              <option value="">Select an option</option>
                            </>
                          )}
                        </select>
                      </div>
                    </div>
                    <div className="table-row">
                      <div className="header table-cell">Enter Address</div>
                      <div className="table-cell">
                        <textarea
                          rows="3"
                          cols="15"
                          value={textAddressValue}
                          onChange={handleTextAddChange}
                          placeholder="Enter Address here..."
                        />
                      </div>
                    </div>
                    {/* Add more rows as needed */}
                  </div>
                </div>
              </div>
              {/* DATA END TABLE */}
            </div>
            <div className="modal-footer">
              <button
                className="btn btn-secondary"
                type="button"
                data-dismiss="modal"
              >
                Cancel
              </button>
              <a
                className="btn btn-primary update-btn"
                type="button"
                data-dismiss="modal"
                onClick={updateFmaily}
              >
                <span aria-hidden="true">Update</span>
              </a>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Editmembers;
