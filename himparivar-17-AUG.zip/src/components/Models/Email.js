import React, { useState } from "react";
import "../Models/Editmembers.css";
const Email = (props) => {
  const arrDT = props.OnEmailDetails;
  const [emailText, setEmail] = useState("");
  const [validations, setValidations] = useState([]);

  // Initialize state for member emails
  const [emailID, setEmailID] = useState([]);

  const handleEmailChange = (event, index) => {
    const newEmailID = [...emailID];
    newEmailID[index] = event.target.value;
    setEmailID(newEmailID);

   // Basic validation using a regular expression
    const email =  /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/; //email vaildation

    const newValidations = [...validations];
    newValidations[index] = email.test(newEmailID[index]);
    setValidations(newValidations);
  };

  const updateEmailID = () => {
    props.callCloseAndTickUpdate("tick-email");
    //console.log(selectedOptions);
  };
  return (
    <>
      {/* <!-- Logout Modal--> */}
      <div
        className="modal fade"
        id="emailid"
        tabIndex="-1"
        role="dialog"
        aria-labelledby="exampleModalLabel"
        aria-hidden="true"
      >
        <div className="modal-dialog modal-dialog-shop " role="document">
          <div className="modal-content model-edit-members">
            <div className="modal-header">
              <h5 className="modal-title" id="exampleModalLabel">
                Mobile No Details
              </h5>
              <button
                className="close"
                type="button"
                data-dismiss="modal"
                aria-label="Close"
              >
                <span aria-hidden="true">×</span>
              </button>
            </div>
            <div className="modal-body">
              {/* START DATA  TABLE */}
              {/* <!-- DataTales Example --> */}
              <div className="card shadow mb-4">
                <div className="card-header py-3">
                  <h6 className="m-0 font-weight-bold text-primary">
                    Update Mobile No
                  </h6>
                </div>
                <div className="card-body">
                  <div className="table-responsive">
                    <table style={{ display: "" }}>
                      {arrDT ? (
                        arrDT.map((item, index) => (
                          <>
                            <tr>
                              <td>{item.memberName}</td>
                              <td>
                                <input
                                  type=""
                                  name={
                                    "email_" + item.memberName.replace(/\s/g, "")
                                  }
                                  id={
                                    "email_" + item.memberName.replace(/\s/g, "")
                                  }
                                  value={emailID[index] || ""}
                                  onChange={(event) =>
                                    handleEmailChange(event, index)
                                  }
                                  placeholder="Enter valid email."
                                />
                                {validations[index] ? null : (
                                  <p className="error">
                                    Please enter valid email.
                                  </p>
                                )}
                              
                              </td>
                            </tr>
                          </>
                        ))
                      ) : (
                        <></>
                      )}
                    </table>
                  </div>
                </div>
              </div>
              {/* DATA END TABLE */}
            </div>
            <div className="modal-footer">
              <button
                className="btn btn-secondary"
                type="button"
                data-dismiss="modal"
              >
                Cancel
              </button>
              <a
                className="btn btn-primary update-btn"
                type="button"
                data-dismiss="modal"
                aria-label="Close"
                onClick={updateEmailID}
              >
                <span aria-hidden="true">Update</span>
              </a>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Email;
