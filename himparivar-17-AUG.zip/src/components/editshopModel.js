import React, { Component } from 'react';
 
class editshopModel extends Component {
  render() {
    return (
      <>
      {alert("deeee")}
       NEW Component ADDED
      </>
    );
}
}
 
export default editshopModel;