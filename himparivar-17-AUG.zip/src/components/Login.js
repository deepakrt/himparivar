import React,{Component} from 'react';
import './Login.css';
import './Login2.css';
import  Captcha from './Captcha.js';
import { event } from 'jquery';
import { Outlet, Link } from "react-router-dom";


class LoginApp extends Component {
	render(){
		return(
			<div className="container ftco-section">
			<div className="LoginApp align-items-center" style={{marginTop:"-50px"}}>
				<div className="row col-md-12 ">            
				<div className="col-md-8 col-lg-5 align-items-center mgn-lbox" >
						<div className="login-wrap p-4 p-md-4 ">
					  <div className="icon d-flex align-items-center justify-content-center">
					  <img src="images/logo.png" alt="logo" width="150%"/>
					  </div>
					  <h3 className="text-center mb-8 h3 mb-0 text-gray-800">Member Login</h3>
						<form action="#" className="login-form">
						  <div className="form-group">
							  <input type="text" name='username' id='username' className="form-control rounded-left" placeholder="Username" required/>
						  </div>
					<div className="form-group d-flex">
					  <input type="password" name='password' id='password' className="form-control rounded-left" placeholder="Password" required/>
					</div>
					<div className="form-group">
					<Captcha/>
					</div>

					{/* <div className="form-group">
						<button type="submit" className="form-control btn btn-primary rounded submit px-3">Login</button>
					</div> */}
					
					<div className="form-group d-md-flex">
						<div className="w-50">
							
									</div>
									<div className="w-50 text-md-right">
										<a href="#">Forgot Password</a>
									</div>
					</div>
				  </form>
				</div>
					</div>
					</div>
			</div>
			</div>
		)
	}

}




export default LoginApp;