import React, { useState } from "react";
import axios from "axios"; // Import the axios library

const Users = () => {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState("");

  const handleLogin = async () => {
    try {
      const apiUrl = "urban-dept/login";

      const postData = {
        username: username,
        password: password,
      };

      const response = await axios.post(apiUrl, postData, {
        headers: {
          "Content-Type": "application/json",
        },
      });

      if (response.status === 200) {
        setMessage("Login Successful!");
      } else {
        setMessage("Login failed. Please check your credentials.");
      }
    } catch (error) {
      console.error("GET Request Error:", error);
      setMessage("Login failed. Please check your credentials.");
    }
  };

  const handleGetRequest = async () => {
    try {
      const apiUrl = "urban-dept/getlogin";

      const response = await axios.get(apiUrl);

      if (response.status === 200) {
        console.log("GET Response:", response.data);
      } else {
        console.error("GET Request Error:", response.statusText);
      }
    } catch (error) {
      console.error("GET Request Error:", error);
    }
  };

  return (
    <div>
      <h2>Login Form</h2>
      <div>
        <label>Username:</label>
        <input
          type="text"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
        />
      </div>

      <div>
        <label>Password:</label>
        <input
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
      </div>

      <button onClick={handleLogin}>Login</button>

      <button onClick={handleGetRequest}>Make GET Request</button>

      <p>{message}</p>
    </div>
  );
};

export default Users;

// import React, { useState,useEffect } from "react";

// function Users() {

//     const [users,setUsres]=useState([]);

//     useEffect(() => {

//         fetch("/users/").then(res=>{
//             if(res.ok){
//                     return res.json()
//             }
//             alert(res.json());

//         }).then(jsonRes=>setUsres(jsonRes.usersList))

//       })

//     return (
//       <div >
//        {users.map(user=><li>{user}</li>)}
//       </div>
//     );
//   }

//   export default Users;
