import React, { Component } from 'react';

export default function HeaderBar (props) {
  
  
     // const [memberList, setMemberList] = useState();
     const loggedUser = JSON.parse(localStorage.getItem("loggedUser"));
     var authToken = loggedUser.data.token;
     //console.log(authToken);
    return (
      <>
               {/* <!-- Topbar --> */}
               <div className="d-sm-flex align-items-center justify-content-between mb-4">
                  Login at : {loggedUser.timestamp}
                  
                  <div
                    className="row justify-content-between mb-4"
                    style={{ border: "0px solid red" }}
                  >
                    <h1 className="h3 mb-0 text-gray-800">{props.titlePage}</h1>
                  </div>
                  <a
                    href="#"
                    data-toggle="modal"
                    data-target="#logoutModal"
                    className="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"
                  >
                    <i className="fas fa-sign-out-alt fa-sm text-white-50"></i>{" "}
                    Logout
                  </a>
                </div>
              {/* <!-- End of Topbar --> */}
      </>
    );
  
}
 


