import React, { useState, useEffect } from "react";
import "../Models/Editmembers.css";
import { useNavigate } from "react-router-dom";
const Verifyadhaar = (props) => {
  const arrDT = props.OnVerifyadhaarDetails;
  const [adhaarNumber, setAdhaarNumber] = useState([]);
  const [validations, setValidations] = useState([]);

  const handleAdhaarNo = (event, index) => {
    const newAdhaarNumbers = [...adhaarNumber];
    newAdhaarNumbers[index] = event.target.value;
    setAdhaarNumber(newAdhaarNumbers);

    // Basic validation using a regular expression
    const adhaarCPattern = /^\d{12}$/;

    const newValidations = [...validations];
    newValidations[index] = adhaarCPattern.test(newAdhaarNumbers[index]);
    setValidations(newValidations);
  };

  const updateAdhaar = () => {
    props.callCloseAndTickUpdate("tick-veryadhaar");
  };
  return (
    <>
      {/* <!-- Logout Modal--> */}
      <div
        className="modal fade"
        id="verifyadhaar"
        tabIndex="-1"
        role="dialog"
        aria-labelledby="exampleModalLabel"
        aria-hidden="true"
      >
        <div className="modal-dialog modal-dialog-shop " role="document">
          <div className="modal-content model-edit-members">
            <div className="modal-header">
              <h5 className="modal-title" id="exampleModalLabel">
                Verify Adhaar Card
              </h5>
              <button
                className="close"
                type="button"
                data-dismiss="modal"
                aria-label="Close"
              >
                <span aria-hidden="true">×</span>
              </button>
            </div>
            <div className="modal-body">
              {/* START DATA  TABLE */}
              {/* <!-- DataTales Example --> */}
              <div className="card shadow mb-4">
                <div className="card-header py-3">
                  <h6 className="m-0 font-weight-bold text-primary">Update </h6>
                </div>
                <div className="card-body">
                  <div className="table-responsive">
                    <table style={{ display: "" }}>
                      {arrDT ? (
                        arrDT.map((item, index) => (
                          <>
                            <tr>
                              <td>{item.memberName}</td>
                              <td>
                                {item.ekycStatus.replace(/\s/g, "") ===
                                "eKYCCompliant" ? (
                                  <>
                                    <input
                                      type="text" // Set the appropriate type
                                      name={
                                        "adhaar_" +
                                        item.memberName.replace(/\s/g, "")
                                      }
                                      id={
                                        "adhaar_" +
                                        item.memberName.replace(/\s/g, "")
                                      }
                                      value={
                                        adhaarNumber[index] ||
                                        item.aadhaarNumber
                                      }
                                      onChange={(event) =>
                                        handleAdhaarNo(event, index)
                                      }
                                      maxLength={12}
                                      readOnly
                                      style={{ width: "70%" }}
                                    />
                                    <span
                                      class="btn btn-success btn-circle btn-sm"
                                      style={{
                                        width: "10%",
                                        height: "10%",
                                        marginLeft: "2px",
                                      }}
                                    >
                                      <i class="fas fa-check"></i>
                                    </span>
                                  </>
                                ) : (
                                  <>
                                    <input
                                      type="text" // Set the appropriate type
                                      name={
                                        "adhaar_" +
                                        item.memberName.replace(/\s/g, "")
                                      }
                                      id={
                                        "adhaar_" +
                                        item.memberName.replace(/\s/g, "")
                                      }
                                      value={
                                        adhaarNumber[index] ||
                                        item.aadhaarNumber
                                      }
                                      onChange={(event) =>
                                        handleAdhaarNo(event, index)
                                      }
                                      maxLength={12}
                                      style={{ width: "70%" }}
                                    />
                                     <span
                                      class="btn btn-danger btn-circle btn-sm"
                                      style={{
                                        width: "10%",
                                        height: "10%",
                                        marginLeft: "2px",
                                      }}
                                    >
                                      <i class="fas fa-info-circle"></i>
                                    </span>
                                  </>
                                )}

                                {/* {validations[index] ? (
                                <>
                                <p className="error">
                                    Please enter valid adhaar.
                                  </p>
                                </>) : (<></>)} */}
                              </td>
                            </tr>
                          </>
                        ))
                      ) : (
                        <></>
                      )}
                    </table>
                  </div>
                </div>
              </div>
              {/* DATA END TABLE */}
            </div>
            <div className="modal-footer">
              <button
                className="btn btn-secondary"
                type="button"
                data-dismiss="modal"
              >
                Cancel
              </button>
              <a
                className="btn btn-primary update-btn"
                type="button"
                data-dismiss="modal"
                aria-label="Close"
                onClick={updateAdhaar}
              >
                <span aria-hidden="true">Update</span>
              </a>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Verifyadhaar;
