import React, { useState, useEffect } from "react";
import "../Models/Editmembers.css";
const Editmembers = (props) => {
  const [selectedOptionsnames, setSelectedOptionsnames] = useState({});
  const [selectedOptionsEC, setSelectedOptionsEC] = useState({});
  const [selectedOptionsRL, setSelectedOptionsRL] = useState({});
  const [selectedOptionsSC, setSelectedOptionsSC] = useState({});
  const [selectedOptionsRes, setSelectedOptionsRes] = useState({});
  const [selectedOptionsDist, setSelectedOptionsDist] = useState({});
  const [selectedOptionsMunci, setSelectedOptionsMunci] = useState({});
  const [selectedOptionsMunciVal, setSelectedOptionsMunciVal] = useState({});
  const [selectedOptionsWard, setSelectedOptionsWard] = useState({});
  const [selectedOptionsWardVal, setSelectedOptionsWardVal] = useState({});

  const arrDT = props.OnEditMemberDetails;
  // const arrEC = props.arrSelectedOptionsEc;
  const arrEC2 = JSON.parse(JSON.stringify(props.arrSelectedOptionsEc));
  const arrRL = JSON.parse(JSON.stringify(props.arrSelectedOptionsRL));
  const arrSC = JSON.parse(JSON.stringify(props.arrSelectedOptionsSC));
  const arrRes = JSON.parse(JSON.stringify(props.arrSelectedOptionsRes));
  const arrDist = JSON.parse(JSON.stringify(props.arrSelectedOptionsDist));
  const arrMunci = JSON.parse(JSON.stringify(props.arrSelectedOptionsMunci));
  const loggedUser = JSON.parse(localStorage.getItem("loggedUser"));
  var authToken = loggedUser.data.token;

 // console.log(arrDist);

  // SELECT NAME FOR HoF
  const handleSelectChangeNames = (event) => {
    setSelectedOptionsnames(event.target.value);
  };
  // SELECT EC
  const handleSelectEC = (event) => {
    setSelectedOptionsEC(event.target.value);
  };

  // SELECT RL
  const handleSelectRL = (event) => {
    setSelectedOptionsRL(event.target.value);
  };
  // SELECT SC
  const handleSelectSC = (event) => {
    setSelectedOptionsSC(event.target.value);
  };
  // SELECT RES
  const handleSelectRes = (event) => {
    setSelectedOptionsRes(event.target.value);
  };

  //---------------------------
  
  // SELECT Dist
  const handleSelectDist = (event) => {
    const DistCode = event.target.value;

    

    //GET LIST FOR MUNCI FROM API
    const requestOptions = {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        Authorization: "Bearer " + authToken,
      },
    };
    const apiUrlMunci = "urban-dept/getMunicipalities?districtCode=" + DistCode;
    fetch(apiUrlMunci, requestOptions)
      .then((response) => {
       // console.log(response);

        if (response.status == "500") {
          //API ERROR
          console.log("API ERROR 500");
        }

        if (!response.ok) {
          throw new Error("Network response was not ok");
        }

        return response.json();
      })
      .then((data) => {
        if (data.status === "OK") {
          setSelectedOptionsMunci(JSON.parse(JSON.stringify(data)));
          //return data;
        } else {
          console.log("Request is not successful!");
        }
      })
      .catch((error) => {
        console.error("Error:", error);
      }, []);
    //---------------------------

    setSelectedOptionsDist(event.target.value);
  };
  // SELECT Munci
  const handleSelectMunci = (event) => {
    const MunciID = event.target.value;
    //GET LIST FOR WARDS FROM API
    const requestOptions = {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        Authorization: "Bearer " + authToken,
      },
    };
    const apiUrlMunci = "urban-dept/getWards?municipalId=" + MunciID;
    fetch(apiUrlMunci, requestOptions)
      .then((response) => {
       // console.log(response);

        if (response.status == "500") {
          //API ERROR
          console.log("API ERROR 500");
        }

        if (!response.ok) {
          throw new Error("Network response was not ok");
        }

        return response.json();
      })
      .then((data) => {
        if (data.status === "OK") {
          setSelectedOptionsWard(JSON.parse(JSON.stringify(data)));
          //return data;
        } else {
          console.log("Request is not successful!");
        }
      })
      .catch((error) => {
        console.error("Error:", error);
      }, []);
    //---------------------------
    setSelectedOptionsMunciVal(event.target.value);
  };
  // SELECT Ward
  const handleSelectWard = (event) => {
    setSelectedOptionsWardVal(event.target.value);
  };
  
  // Address
  const [textAddressValue, setTextAddressValue] = useState('');

  const handleTextAddChange = (event) => {
    setTextAddressValue(event.target.value);
  };
  const updateFmaily = () => {
    props.callCloseAndTickUpdate("family-d");
     
    
  };

  return (
    <>
      {/* <!-- Logout Modal--> */}
      <div
        className="modal fade"
        id="editmembers"
        tabIndex="-1"
        role="dialog"
        aria-labelledby="exampleModalLabel"
        aria-hidden="true"
      >
        <div className="modal-dialog modal-dialog-shop " role="document">
          <div className="modal-content model-edit-members">
            <div className="modal-header">
              <h5 className="modal-title" id="exampleModalLabel">
                Family Details
              </h5>
              <button
                className="close"
                type="button"
                data-dismiss="modal"
                aria-label="Close"
              >
                <span aria-hidden="true">×</span>
              </button>
            </div>
            <div className="modal-body">
              {/* START DATA  TABLE */}
              {/* <!-- DataTales Example --> */}
              <div className="card shadow mb-4">
                <div className="card-header py-3">
                  <h6 className="m-0 font-weight-bold text-primary">
                    Update Family Details
                  </h6>
                </div>
                <div className="card-body">
                  <div className="table-container">
                    <div className="table-row">
                      <div className="header table-cell">Head of Family</div>
                      <div className="table-cell">
                        <select
                          name="hof-name"
                          id="hof-name"
                          value={selectedOptionsnames}
                          onChange={handleSelectChangeNames}
                        >
                          {arrDT ? (
                            arrDT.map((item, index) => (
                              <>
                                <option value={item.memberName}>
                                  {item.memberName}
                                </option>
                              </>
                            ))
                          ) : (
                            <>
                              <option value="">Select an option</option>
                            </>
                          )}
                        </select>
                      </div>
                    </div>
                    <div className="table-row">
                      <div className="header table-cell">Economic Level</div>
                      <div className="table-cell">
                        <select
                          name="economic-level"
                          id="economic-level"
                          value={selectedOptionsEC}
                          onChange={handleSelectEC}
                        >
                          {arrEC2.data ? (
                            arrEC2.data.map((item, index) => (
                              <>
                                <option value={item.id}>
                                  {item.economicStatus}
                                </option>
                              </>
                            ))
                          ) : (
                            <>
                              <option value="">Select an option</option>
                            </>
                          )}
                        </select>
                      </div>
                    </div>
                    <div className="table-row">
                      <div className="header table-cell">Religion</div>
                      <div className="table-cell">
                        <select
                          name="religions"
                          id="religions"
                          value={selectedOptionsRL}
                          onChange={handleSelectRL}
                        >
                          {arrRL.data ? (
                            arrRL.data.map((item, index) => (
                              <>
                                <option value={item.id}>
                                  {item.religionName}
                                </option>
                              </>
                            ))
                          ) : (
                            <>
                              <option value="">Select an option</option>
                            </>
                          )}
                        </select>
                      </div>
                    </div>
                    <div className="table-row">
                      <div className="header table-cell">Social Category</div>
                      <div className="table-cell">
                        <select
                          name="social-cat"
                          id="social-cat"
                          value={selectedOptionsSC}
                          onChange={handleSelectSC}
                        >
                          {arrSC.data ? (
                            arrSC.data.map((item, index) => (
                              <>
                                <option value={item.id}>
                                  {item.socialCategoryNameEnglish}
                                </option>
                              </>
                            ))
                          ) : (
                            <>
                              <option value="">Select an option</option>
                            </>
                          )}
                        </select>
                      </div>
                    </div>
                    <div className="table-row">
                      <div className="header table-cell">Resident Status</div>
                      <div className="table-cell">
                        <select
                          name="resedential-st"
                          id="resedential-st"
                          value={selectedOptionsRes}
                          onChange={handleSelectRes}
                        >
                          {arrRes.data ? (
                            arrRes.data.map((item, index) => (
                              <>
                                <option value={item.id}>
                                  {item.locationName}
                                </option>
                              </>
                            ))
                          ) : (
                            <>
                              <option value="">Select an option</option>
                            </>
                          )}
                        </select>
                      </div>
                    </div>
                    <div className="table-row">
                      <div className="header table-cell">District</div>
                      <div className="table-cell">
                        <select
                          name="dist-lst"
                          id="dist-lst"
                          value={selectedOptionsDist}
                          onChange={handleSelectDist}
                        >
                          {arrDist.data ? (
                            arrDist.data.map((item, index) => (
                              <>
                                <option value={item.districtCode}>
                                  {item.districtName}
                                </option>
                              </>
                            ))
                          ) : (
                            <>
                              <option value="">Select an option</option>
                            </>
                          )}
                        </select>
                      </div>
                    </div>
                    <div className="table-row">
                      <div className="header table-cell">Muncipality</div>
                      <div className="table-cell">
                        <select
                          name="munci-lst"
                          id="munci-lst"
                          value={selectedOptionsMunciVal}
                          onChange={handleSelectMunci}
                        >
                          <option value="" selected>Select</option>
                          {selectedOptionsMunci.data ? (
                            selectedOptionsMunci.data.map((item, index) => (
                              <>
                                <option value={item.municipalId}>
                                  {item.municipalName}
                                </option>
                              </>
                            ))
                          ) : (
                            <>
                              <option value="">Select an option</option>
                            </>
                          )}
                        </select>
                      </div>
                    </div>
                    <div className="table-row">
                      <div className="header table-cell">Ward</div>
                      <div className="table-cell">
                        <select
                          name="munci-lst"
                          id="munci-lst"
                          value={selectedOptionsWardVal}
                          onChange={handleSelectWard}
                        >
                          {selectedOptionsWard.data ? (
                            selectedOptionsWard.data.map((item, index) => (
                              <>
                                <option value={item.id}>
                                  {item.wardNo + " " + item.wardName}
                                </option>
                              </>
                            ))
                          ) : (
                            <>
                              <option value="">Select an option</option>
                            </>
                          )}
                        </select>
                      </div>
                    </div>
                    <div className="table-row">
                      <div className="header table-cell">Enter Address</div>
                      <div className="table-cell">
                        <textarea
                          rows="3"
                          cols="15"
                          value={textAddressValue}
                          onChange={handleTextAddChange}
                          placeholder="Enter Address here..."
                        />
                      </div>
                    </div>
                    {/* Add more rows as needed */}
                  </div>
                </div>
              </div>
              {/* DATA END TABLE */}
            </div>
            <div className="modal-footer">
              <button
                className="btn btn-secondary"
                type="button"
                data-dismiss="modal"
              >
                Cancel
              </button>
              <a
                className="btn btn-primary update-btn"
                type="button"
                data-dismiss="modal"
                onClick={updateFmaily}
              >
                <span aria-hidden="true">Update</span>
              </a>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Editmembers;
