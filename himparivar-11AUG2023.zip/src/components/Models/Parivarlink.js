import React, { useState } from "react";
import "../Models/Editmembers.css";
const Parivarlink = (props) => {

    const [memberDetails, setMemberDetails] = useState();
   
    //setMemberDetails(props.OnEditMemberDetails());

    //console.log(memberDetails);
  return (
    <>
      {/* <!-- Logout Modal--> */}
      <div
        className="modal fade"
        id="parivarlinkdetails"
        tabIndex="-1"
        role="dialog"
        aria-labelledby="exampleModalLabel"
        aria-hidden="true"
      >
        <div className="modal-dialog modal-dialog-shop " role="document">
          <div className="modal-content model-edit-members">
            <div className="modal-header">
              <h5 className="modal-title" id="exampleModalLabel">
              Parivar Link
              </h5>
              <button
                className="close"
                type="button"
                data-dismiss="modal"
                aria-label="Close"
              >
                <span aria-hidden="true">×</span>
              </button>
            </div>
            <div className="modal-body">
             {/* START DATA  TABLE */}
             {/* <!-- DataTales Example --> */}
                    <div className="card shadow mb-4">
                        <div className="card-header py-3">
                            <h6 className="m-0 font-weight-bold text-primary">Edit Member Details</h6>
                        </div>
                        <div className="card-body">
                            <div className="table-responsive">
                               DEEEEEEEEEEEEEEEEEE EDIT MEMBERS
                            </div>
                        </div>
                    </div>
              {/* DATA END TABLE */}
            </div>
            <div className="modal-footer">
              <button
                className="btn btn-secondary"
                type="button"
                data-dismiss="modal"
              >
                Cancel
              </button>
              <a className="btn btn-primary" href="/">
                Update
              </a>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Parivarlink;
