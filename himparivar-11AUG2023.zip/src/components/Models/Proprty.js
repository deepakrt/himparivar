import React, { useState } from "react";
import "../Models/Editmembers.css";
const Proprty = (props) => {

    const [memberDetails, setMemberDetails] = useState();
   
    //setMemberDetails(props.OnEditMemberDetails());
    const handlePropType = () => {
      
    };

    const updateProperty = () => {
      props.callCloseAndTickUpdate("tick-property");
    };
  return (
    <>
      {/* <!-- Logout Modal--> */}
      <div
        className="modal fade"
        id="peropertydetails"
        tabIndex="-1"
        role="dialog"
        aria-labelledby="exampleModalLabel"
        aria-hidden="true"
      >
        <div className="modal-dialog modal-dialog-shop " role="document">
          <div className="modal-content model-edit-members">
            <div className="modal-header">
              <h5 className="modal-title" id="exampleModalLabel">
              Property Details
              </h5>
              <button
                className="close"
                type="button"
                data-dismiss="modal"
                aria-label="Close"
              >
                <span aria-hidden="true">×</span>
              </button>
            </div>
            <div className="modal-body">
             {/* START DATA  TABLE */}
             {/* START DATA  TABLE */}
              {/* <!-- DataTales Example --> */}
              <div className="card shadow mb-4">
                <div className="card-header py-3">
                  <h6 className="m-0 font-weight-bold text-primary">
                    Update Property Details
                  </h6>
                </div>
                <div className="card-body">
                  <div className="table-container">
                    <div className="table-row">
                      <div className="header table-cell">Property Type</div>
                      <div className="table-cell">
                        <select name="selProp" id="selProp" onChange={handlePropType}>
                          <option value="r">Rented</option>
                          <option value="o">Owned</option>
                        </select>
                      </div>
                    </div>
                    <div className="table-row">
                      <div className="header table-cell">Property ID</div>
                      <div className="table-cell">
                       <input type="" name="" value=""/>
                      </div>
                    </div>
                    <div className="table-row">
                      <div className="header table-cell">Landloard Name</div>
                      <div className="table-cell">
                       <input type="" name="" value=""/>
                      </div>
                    </div>
                   
                    {/* Add more rows as needed */}
                  </div>
                </div>
              </div>
              {/* DATA END TABLE */}
            </div>
            <div className="modal-footer">
              <button
                className="btn btn-secondary"
                type="button"
                data-dismiss="modal"
              >
                Cancel
              </button>
              <a
                className="btn btn-primary update-btn"
                type="button"
                data-dismiss="modal"
                aria-label="Close"
                onClick={updateProperty}
              >
                <span aria-hidden="true">Update</span>
              </a>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Proprty;
