import React, { useState } from "react";
//import "./Editshoplist.css";
const Wmessage = (props) => {
  return (
    <>
      {/* <!-- Logout Modal--> */}
      <div
        className="modal fade"
        id="wmessage"
        tabIndex="-1"
        role="dialog"
        aria-labelledby="exampleModalLabe3"
        aria-hidden="true"
      >
        <div className="modal-dialog modal-dialog-shop" role="document">
          <div className="modal-content">
            <div className="modal-header">
             <div className=" text-center">
            <p className="h1" style={{color:"#E74A3B"}}><div className="text-center">
            <i class="fa fa-exclamation-triangle" aria-hidden="true"></i>
                </div> </p>
            </div>
              <button
                className="close"
                type="button"
                data-dismiss="modal"
                aria-label="Close"
              >
                <span aria-hidden="true">×</span>
              </button>
            </div>

            <div className="modal-body">
              {/* START DATA  TABLE */}
              {/* <!-- DataTales Example --> */}
              <div className="card shadow mb-4">
                <div className="card-body">
                <p className="h5 text-justify">    
                Family" means a joint family of all persons descended from common ancestor, who live, worship and mess together permanently as shown in the Pariwar Register of the Panchayat but persons residing elsewhere due to their profession/business shall not be included in the family for the purpose of issue of Ration card.
                </p>
                </div>
              </div>
              {/* DATA END TABLE */}
            </div>
            <div className="modal-footer">
              <button
                className="btn btn-secondary"
                type="button"
                data-dismiss="modal"
              >
                OK
              </button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Wmessage;
