import React, { useState, useEffect } from "react";
import "../Models/Editmembers.css";
import { DatePicker, LocalizationProvider } from "@mui/x-date-pickers";
import dayjs from "dayjs";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";

const Dob = (props) => {
  const arrDT = props.OnDoBDetails;
  const [startDate, setStartDate] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState([]);

  const handleDateChange = (date, pickerId,membername) => {
    // alert(membername)
    // alert(date)
    // alert(pickerId)
    // You can use the pickerId to determine which DatePicker was clicked
    // if (pickerId === 'datepicker-1') {
    //   setSelectedDate1(date);
    // } else if (pickerId === 'datepicker-2') {
    //   setSelectedDate2(date);
    // }
  };

  const updateDoB = () => {
    props.callCloseAndTickUpdate("tick-dob");
  };

  return (
    <>
      {/* <!-- Logout Modal--> */}
      <div
        className="modal fade"
        id="dob"
        tabIndex="-1"
        role="dialog"
        aria-labelledby="exampleModalLabel"
        aria-hidden="true"
      >
        <div className="modal-dialog modal-dialog-shop " role="document">
          <div className="modal-content model-edit-members">
            <div className="modal-header">
              <h5 className="modal-title" id="exampleModalLabel">
                Date Of Birth
              </h5>
              <button
                className="close"
                type="button"
                data-dismiss="modal"
                aria-label="Close"
              >
                <span aria-hidden="true">×</span>
              </button>
            </div>
            <div className="modal-body">
              {/* START DATA  TABLE */}
              {/* <!-- DataTales Example --> */}
              <div className="card shadow mb-4">
                <div className="card-header py-3">
                  <h6 className="m-0 font-weight-bold text-primary">
                    Enter Date Of Birth
                  </h6>
                </div>
                <div className="card-body">
                  <div className="table-responsive">
                    <table style={{ display: "" }}>
                      {arrDT ? (
                        arrDT.map((item, index) => (
                          <>
                            <tr>
                              <td>{item.memberName}</td>
                              <td>
                                <LocalizationProvider
                                  dateAdapter={AdapterDayjs}
                                >
                                  <DatePicker
                                    id={"datepicker-"+index}
                                    defaultValue={dayjs()}
                                    dateFormat="/dd/MM/yyyy"
                                    onChange={(date) => handleDateChange(date,"datepicker-"+index,item.memberName)}
                                  />
                                </LocalizationProvider>
                              </td>
                            </tr>
                          </>
                        ))
                      ) : (
                        <></>
                      )}
                    </table>
                  </div>
                </div>
              </div>
              {/* DATA END TABLE */}
            </div>
            <div className="modal-footer">
              <button
                className="btn btn-secondary"
                type="button"
                data-dismiss="modal"
              >
                Cancel
              </button>
              <a
                className="btn btn-primary update-btn"
                type="button"
                data-dismiss="modal"
                onClick={updateDoB}
              >
                <span aria-hidden="true">Update</span>
              </a>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Dob;
