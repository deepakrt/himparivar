import React, { useState,useEffect } from "react";
const MyComponent = () => {  

   const cors = require("cors");
   
    const [username, setName] = useState("");
    const [password, setEmail] = useState("");

    const handleNameChange = (event) => {
      setName(event.target.value);
    };

  const handleEmailChange = (event) => {
    setEmail(event.target.value);
  };

  const handleSubmit = (event) => {
    event.preventDefault();

    // Prepare the data to be sent in the POST request
    const postData = {
      username: document.getElementById("username").value,
      password: document.getElementById("password").value,
    };

    // URL of the REST API endpoint where you want to create a new resource
    const apiUrl = "urban-dept/login"; // Replace this with your actual API endpoint

    // Request options for the fetch function
    const requestOptions = {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        // Add any other headers required by your API, e.g., authentication tokens, etc.
      },
      body: JSON.stringify(postData),
    };

    // Use fetch to make the POST request
    fetch(apiUrl, requestOptions)
      .then((response) => {
        if (!response.ok) {
          // Handle error responses (non-2xx status codes)
          throw new Error("Network response was not ok");
        }
        // If the response is successful, parse the JSON data from the response
        return response.json();
      })
      .then((data) => {
        // Handle the data returned from the server after successful creation
        console.log("New user created:", data);
        // You can add any further logic here based on the response from the server
      })
      .catch((error) => {
        // Handle any errors that occurred during the fetch process
        console.error("Error: Here is the problem", error);
      });
  };

  return (
    <form onSubmit={handleSubmit}>
      <div>
        <label>Name:</label>
        <input type="text" name='username' id='username' value="Khaliyar" onChange={handleNameChange} />
      </div>
      <div>
        <label>Passwword:</label>
        <input type="password" name='password' id='password' value="1234" onChange={handleEmailChange} />
      </div>
      <button type="submit">Submit</button>
    </form>
  );
};

export default MyComponent;