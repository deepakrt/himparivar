import React,{Component} from 'react';
import ReactDOM from "react-dom/client";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import LoginApp from "./components/Login";
import Layout from "./pages/Layout/Layout";
import LMenu from "./components/LMenu";
import Dashboard from "./pages/Dashboard";
import AddnewParivar from "./pages/AddnewParivar";
import AddnewFamily from "./pages/AddnewFamily";
import Contact from "./pages/Contact";
import NoPage from "./pages/NoPage";
import Tpage from "./pages/Tpage";
import SelectedMembers from "./pages/SelectedMembers";
import { useState, useEffect } from "react";

export default function App() {

  // /*** Start - Disable Mouse Right Click ***/

//   useEffect(() => {
//     const handleContextmenu = e => {
//         e.preventDefault()
//     }
//     document.addEventListener('contextmenu', handleContextmenu)
//     return function cleanup() {
//         document.removeEventListener('contextmenu', handleContextmenu)
//     }
// }, [ ])

//  /*** End - Disable Mouse Right Click ***/



  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<LoginApp />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/login" element={<LoginApp />} />
          <Route path="/addpar" element={<AddnewParivar />} />
          <Route path="/addfamily" element={<AddnewFamily />} />
          <Route path="/selmembers" element={<SelectedMembers/>} />
          <Route path="/tpage" element={<Tpage />} />
          <Route path="*" element={<NoPage />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}
const root = ReactDOM.createRoot(document.getElementById("root"),[]);
root.render(
  <React.Fragment><App /></React.Fragment>
);




