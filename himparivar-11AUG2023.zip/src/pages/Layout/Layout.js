import React, { Component } from "react";
import { Outlet, Link } from "react-router-dom";
import "./layout-css/sb-admin-2.css";
import "./layout-css/sb-admin-2.min.css";
import "./fontawesome-free/css/all.min.css";
//import './Layout.css';

import { Helmet } from "react-helmet";

class Layout extends Component {
  render() {
    return (
      <>
        <div className="application">
          <Helmet>
            <script src="js/sb-admin-2.min.js"></script>
          </Helmet>
        </div>
        <Outlet />
      </>
    );
  }
}
export default Layout;
