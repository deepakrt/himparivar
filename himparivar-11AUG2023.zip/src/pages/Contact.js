import React,{Component} from 'react';



class Contact extends Component {

	render(){
		return(

			<div className="align-items-center">
				Contact Page
			</div>
		)
	}

}




export default Contact;