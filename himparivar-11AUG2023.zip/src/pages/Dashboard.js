import React, { Component, useState, useEffect } from "react";
import Header from "../components/Header";
import LMenu from "../components/LMenu";
import Footer from "../components/Footer";
import Editshoplist from "../components/Models/Editshoplist";
import Logout from "../components/Logout";
import { Refinedata, FetchApiCall } from "../lib/Fetch";
import { WardMembersFetch } from "../lib/WardMembersFetch";
import { data } from "jquery";

class Dashboard extends Component {
  constructor() {
    super();

    const loggedUser = localStorage.getItem("loggedUser");
    //console.log(loggedUser);
    // Define your initial state here
    this.state = { wardmembers: "" };

    //this.wardMembersState = this.wardMembersState.bind(this);

    if (loggedUser) {
      const loggedUserData = JSON.parse(loggedUser);
    } else {
      window.location = "/";
    }
  }

  render(loggedUserData) {
    // const [memberList, setMemberList] = useState();
    const loggedUser = JSON.parse(localStorage.getItem("loggedUser"));
    var authToken = loggedUser.data.token;
    console.log(authToken);

    // 1. WARD MEMBERS
    const apiUrlWardshop = "urban-dept/fetch-ration-details";
    const requestOptions = {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        Authorization: "Bearer " + authToken,
        rationCardNo: "HP2021072923147",
      },
    };

    let apiWardMembersData = FetchApiCall(apiUrlWardshop, requestOptions);
    //-------------------------------------------------------------------//
    let myPromise = new Promise(function (myResolve, myReject) {
      myResolve(apiWardMembersData);
      this.setState({ wardmembers: apiWardMembersData });
    });
    console.log(this.wardmembers);

    return (
      <>
        <div id="wrapper">
          {/* <!-- Left Menu Bar --> */}
          <LMenu />
          {/* <!-- Left Menu Bar End --> */}
          {/* <!-- Content Wrapper --> */}
          <div id="content-wrapper" className="d-flex flex-column">
            {/* <!-- Page Wrapper --> */}

            {/* <!-- Main Content --> */}
            <div id="content">
              {/* <!-- Begin Page Content --> */}
              {/* <!-- Head Search Bar --> */}
              <Header />
              {/* <!-- Head Search Bar End --> */}
              {/* <!-- Begin Page Content --> */}
              <div className="container-fluid">
                {/* <!-- Page Heading --> */}
                <div className="d-sm-flex align-items-center justify-content-between mb-4">
                  Login at : {loggedUser.timestamp}
                  <div
                    className="row justify-content-between mb-4"
                    style={{ border: "0px solid red" }}
                  >
                    <h1 className="h3 mb-0 text-gray-800">
                      Ward No : {loggedUser.data.ulb.wardNo}
                    </h1>
                  </div>
                  <a
                    href="#"
                    data-toggle="modal"
                    data-target="#logoutModal"
                    className="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"
                  >
                    <i className="fas fa-sign-out-alt fa-sm text-white-50"></i>{" "}
                    Logout
                  </a>
                </div>

                {/* <!-- Content Row --> */}
                <div className="container-fluid">
                  <div className="card mb-8">
                    <div className="card-header">
                      <div className="container">
                        <div className="row">
                          <div className="col">{loggedUser.data.userName}</div>
                          <div className="col text-right">
                            {/* Add Shop Button */}

                            <a
                              href="#"
                              data-toggle="modal"
                              data-target="#editshoplist"
                              className="btn btn-light btn-icon-split"
                              style={{ borderRadius: "0px" }}
                            >
                              <span className="icon text-gray-600">
                                <i className="fas fa-arrow-right"></i>
                              </span>
                              <span className="text">Edit Shops</span>
                            </a>
                            {/* End Shop Button */}
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="d-flex justify-content-between">
                      <div>
                        <div className="card-body col-md-12">
                          <b>Ward Name</b> : {loggedUser.data.ulb.wardName}
                          <br></br>
                          <b>Muncipal Name</b> :{" "}
                          {loggedUser.data.ulb.municipalName}
                          <br></br>
                          <b>Distric Code</b> :{" "}
                          {loggedUser.data.ulb.districtCode}
                          <br></br>
                        </div>
                      </div>
                      <div style={{marginTop:"50px"}}>
                        <a
                          href="#"
                          className="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"
                        >
                          <i className="fas fa-sign-out-alt fa-sm text-white-50"></i>{" "}
                          Survey For Ward {loggedUser.data.ulb.wardNo}
                        </a>
                      </div>
                      <div className="card" style={{ border: "none" }}>
                        <div className="card-body">
                          <div className="row no-gutters align-items-center">
                            <div className="col-auto">
                              <i className="fas fa-store-alt fa-2x text-gray-300"></i>
                            </div>
                            <div className="col mr-2 px-3">
                              <div className="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                Total Ration Shops
                              </div>
                              <div className="h5 mb-0 font-weight-bold text-gray-800">
                                0
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <br />
                 
                </div>
              </div>

              {/* <!-- /.container-fluid --> */}
            </div>
            {/* <!-- End of Main Content --> */}

            {/* <!-- End of Page Wrapper --> */}

            {/* <!-- Footer Section --> */}
            <Footer />
            {/* <!-- Footer Section End --> */}
            {/* <!-- End of Page Wrapper --> */}

            {/* <!-- Scroll to Top Button--> */}
            <a className="scroll-to-top rounded" href="#page-top">
              <i className="fas fa-angle-up"></i>
            </a>

            {/* <!-- Logout Modal--> */}
            <Logout />
            {/* <!-- Edit Shop Modal--> */}
            <Editshoplist datashop="deee" />
          </div>
          {/* <!-- Content-Wrapper End--> */}
        </div>
      </>
    );
  }
}

export default Dashboard;
