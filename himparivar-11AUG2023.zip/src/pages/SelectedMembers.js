import React, { Component, useState, useEffect } from "react";
import Header from "../components/Header";
import HeaderBar from "../components/HeaderBar";
import LMenu from "../components/LMenu";
import Footer from "../components/Footer";
import Logout from "../components/Logout";
import { useParams, useNavigate } from "react-router-dom";
import "../../src/App.css";
// LIB

//-----
//Model Pages
import Editmembers from "../components/Models/Editmembers";
import Gender from "../components/Models/Gender";
import Dob from "../components/Models/Dob";
import Education from "../components/Models/Education";
import Familyrel from "../components/Models/Familyrel";
import Occupation from "../components/Models/Occupation";
import Parivarlink from "../components/Models/Parivarlink";
import Proprty from "../components/Models/Proprty";
import Mobileno from "../components/Models/Mobileno";
import Email from "../components/Models/Email";
import Verifyadhaar from "../components/Models/Verifyadhaar";
//-------------------------------------------------------

const SelectedMembers = () => {
  const selectMembrs = localStorage.getItem("selectedMembers");
  const nArr = JSON.stringify(JSON.parse(selectMembrs));
  const nArr2 = JSON.parse(nArr);
  const [editing, setEditing] = useState(false);
  const [textValues, setTextValues] = useState(nArr2);
  const [memberDt, setMemberDt] = useState();
  const loggedUser = JSON.parse(localStorage.getItem("loggedUser"));
  var authToken = loggedUser.data.token;

  const [selectedOptionsEc, setSelectedOptionsEc] = useState({});
  const [selectedOptionsRL, setSelectedOptionsRL] = useState({});
  const [selectedOptionsSC, setSelectedOptionsSC] = useState({});
  const [selectedOptionsRes, setSelectedOptionsRes] = useState({});
  const [selectedOptionsDist, setSelectedOptionsDist] = useState({});
  const [selectedOptionsMunci, setSelectedOptionsMunci] = useState({});

  useEffect(() => {
    //FETCH DATA FROM API

    const requestOptions = {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        Authorization: "Bearer " + authToken,
      },
    };

    // API FOR EC
    const apiUrl = "urban-dept/getEconomicCategories";
    fetch(apiUrl, requestOptions)
      .then((response) => {
        // ////console.log(response);

        if (response.status == "500") {
          //API ERROR
          console.log("API ERROR 500");
        }

        if (!response.ok) {
          throw new Error("Network response was not ok");
        }

        return response.json();
      })
      .then((data) => {
        if (data.status === "OK") {
          setSelectedOptionsEc(data);
          //return data;
        } else {
          console.log("Request is not successful!");
        }
      })
      .catch((error) => {
        console.error("Error:", error);
      }, []);

    // API FOR RL
    const apiUrlRL = "urban-dept/getReligions";
    fetch(apiUrlRL, requestOptions)
      .then((response) => {
        ////console.log(response);

        if (response.status == "500") {
          //API ERROR
          console.log("API ERROR 500");
        }

        if (!response.ok) {
          throw new Error("Network response was not ok");
        }

        return response.json();
      })
      .then((data) => {
        if (data.status === "OK") {
          setSelectedOptionsRL(data);
          //return data;
        } else {
          console.log("Request is not successful!");
        }
      })
      .catch((error) => {
        console.error("Error:", error);
      }, []);

    // API FOR SC
    const apiUrlSC = "urban-dept/getSocialCategories";
    fetch(apiUrlSC, requestOptions)
      .then((response) => {
        ////console.log(response);

        if (response.status == "500") {
          //API ERROR
          console.log("API ERROR 500");
        }

        if (!response.ok) {
          throw new Error("Network response was not ok");
        }

        return response.json();
      })
      .then((data) => {
        if (data.status === "OK") {
          setSelectedOptionsSC(data);
          //return data;
        } else {
          console.log("Request is not successful!");
        }
      })
      .catch((error) => {
        console.error("Error:", error);
      }, []);

    // API FOR Res
    const apiUrlRes = "urban-dept/getLocations";
    fetch(apiUrlRes, requestOptions)
      .then((response) => {
        ////console.log(response);

        if (response.status == "500") {
          //API ERROR
          console.log("API ERROR 500");
        }

        if (!response.ok) {
          throw new Error("Network response was not ok");
        }

        return response.json();
      })
      .then((data) => {
        if (data.status === "OK") {
          setSelectedOptionsRes(data);
          //return data;
        } else {
          console.log("Request is not successful!");
        }
      })
      .catch((error) => {
        console.error("Error:", error);
      }, []);

    // API FOR Dist
    const apiUrlDist = "urban-dept/getDistricts";
    fetch(apiUrlDist, requestOptions)
      .then((response) => {
        ////console.log(response);

        if (response.status == "500") {
          //API ERROR
          console.log("API ERROR 500");
        }

        if (!response.ok) {
          throw new Error("Network response was not ok");
        }

        return response.json();
      })
      .then((data) => {
        if (data.status === "OK") {
          setSelectedOptionsDist(data);
          //return data;
        } else {
          console.log("Request is not successful!");
        }
      })
      .catch((error) => {
        console.error("Error:", error);
      }, []);

    // END  DATA FROM API
  }, []); // END OF USeEffect

  const arrD1 = () => {};

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setTextValues((prevValues) => ({
      ...prevValues,
      [name]: value,
    }));
  };

  const handleEditClick = () => {
    setEditing(true);
  };

  const handleSaveClick = () => {
    setEditing(false);
  };

  //------------------------------------------------------

  //-------------------------- POP UP FUNCTION ----------------------------------

  const editParivarLinkDetails = (membersInfo) => {
    //SHOW POPUPBOX
    // After the form is submitted, programmatically trigger the modal to show
    const modal = document.getElementById("parivarlinkdetails");

    if (modal) {
      const bootstrapModal = new window.bootstrap.Modal(modal);
      bootstrapModal.show();
      setMemberDt(membersInfo);
      // console.log(membersInfo);
    }

    return memberDt;
    //----------------
  };

  const editPropertyDetails = (membersInfo) => {
    //SHOW POPUPBOX
    // After the form is submitted, programmatically trigger the modal to show
    const modal = document.getElementById("peropertydetails");

    if (modal) {
      const bootstrapModal = new window.bootstrap.Modal(modal);
      bootstrapModal.show();
      setMemberDt(membersInfo);
      // console.log(membersInfo);
    }

    return memberDt;
    //----------------
  };

  const editVerifyAdhaarDetails = (membersInfo) => {
    //SHOW POPUPBOX
    // After the form is submitted, programmatically trigger the modal to show
    const modal = document.getElementById("verifyadhaar");

    if (modal) {
      const bootstrapModal = new window.bootstrap.Modal(modal);
      bootstrapModal.show();
      setMemberDt(membersInfo);
      // console.log(membersInfo);
    }

    return memberDt;
    //----------------
  };

  const editOccupationDetails = (membersInfo) => {
    //SHOW POPUPBOX
    // After the form is submitted, programmatically trigger the modal to show
    const modal = document.getElementById("occupationdetails");

    if (modal) {
      const bootstrapModal = new window.bootstrap.Modal(modal);
      bootstrapModal.show();
      setMemberDt(membersInfo);
      // console.log(membersInfo);
    }

    return memberDt;
    //----------------
  };

  const editEducationDetails = (membersInfo) => {
    //SHOW POPUPBOX
    // After the form is submitted, programmatically trigger the modal to show
    const modal = document.getElementById("educationdetails");

    if (modal) {
      const bootstrapModal = new window.bootstrap.Modal(modal);
      bootstrapModal.show();
      setMemberDt(membersInfo);
      // console.log(membersInfo);
    }

    return memberDt;
    //----------------
  };

  const editFRDetails = (membersInfo) => {
    //SHOW POPUPBOX
    // After the form is submitted, programmatically trigger the modal to show
    const modal = document.getElementById("frddetails");

    if (modal) {
      const bootstrapModal = new window.bootstrap.Modal(modal);
      bootstrapModal.show();
      setMemberDt(membersInfo);
      // console.log(membersInfo);
    }

    return memberDt;
    //----------------
  };

  const editDobDetails = (membersInfo) => {
    //SHOW POPUPBOX
    // After the form is submitted, programmatically trigger the modal to show
    const modal = document.getElementById("dob");

    if (modal) {
      const bootstrapModal = new window.bootstrap.Modal(modal);
      bootstrapModal.show();
      setMemberDt(membersInfo);
      // console.log(membersInfo);
    }

    return memberDt;
    //----------------
  };

  const editGenderDetails = () => {
    //SHOW POPUPBOX
    // After the form is submitted, programmatically trigger the modal to show
    const modal = document.getElementById("gender");
    const memberDt = localStorage.getItem("selectedMembers");

    if (modal) {
      const bootstrapModal = new window.bootstrap.Modal(modal);
      bootstrapModal.show();
    }

    return memberDt;
    //----------------
  };
  const editMemberDetails = () => {
    //SHOW POPUPBOX
    // After the form is submitted, programmatically trigger the modal to show
    const modal = document.getElementById("editmembers");

    if (modal) {
      const bootstrapModal = new window.bootstrap.Modal(modal);
      bootstrapModal.show();
    }

    //----------------
  };

  const editMobileno = () => {
    //SHOW POPUPBOX
    // After the form is submitted, programmatically trigger the modal to show
    const modal = document.getElementById("mobileno");

    if (modal) {
      const bootstrapModal = new window.bootstrap.Modal(modal);
      bootstrapModal.show();
    }

    //----------------
  };

  const editEmailid = () => {
    //SHOW POPUPBOX
    // After the form is submitted, programmatically trigger the modal to show
    const modal = document.getElementById("emailid");

    if (modal) {
      const bootstrapModal = new window.bootstrap.Modal(modal);
      bootstrapModal.show();
    }

    //----------------
  };
  //------------------------------------------------------------------------------------------------------

  const closeAndTickUpdate = (divid) => {
    var inputData = document.getElementById(divid);
    inputData.className = "roundTick";
  };

  return (
    <>
      <div id="wrapper">
        {/* <!-- Left Menu Bar --> */}
        <LMenu />
        {/* <!-- Left Menu Bar End --> */}
        {/* <!-- Content Wrapper --> */}
        <div id="content-wrapper" className="d-flex flex-column">
          {/* <!-- Page Wrapper --> */}

          {/* <!-- Header Content --> */}
          <div id="content">
            {/* <!-- Begin Page Content --> */}
            {/* <!-- Head Search Bar --> */}
            <Header />
            {/* <!-- Head Search Bar End --> */}
            {/* <!-- Begin Page Content --> */}
            <div className="container-fluid">
              {/* <!-- Page Heading --> */}
              <HeaderBar titlePage={"Parivar Members"} />
              {/* <!-- End of Header Content --> */}

              <div className="card shadow mb-4">
                <div className="card-header py-3 font-weight-bold text-primary">
                  <div className="row">
                    <div className="col">Update Members Details</div>
                    <div className="col font-weight-bold text-primary cursor-pointer"></div>
                  </div>
                </div>

                {/* Data Table Start */}
                <div class="container">
                  <br />
                  <div className="row">
                    <div className="col-sm-2"> Ration Card No :</div>
                    <div className="col-sm-3">
                      <b>{nArr2[0].rationCardNumber}</b>
                    </div>
                    <div className="col-sm-7"></div>
                  </div>
                  <div className="row">
                    <div className="col-sm-2"> Block :</div>
                    <div className="col-sm-3">
                      <b>{nArr2[0].block}</b>
                    </div>
                    <div className="col-sm-7"></div>
                  </div>
                  <div className="row">
                    <div className="col-sm-2"> Address :</div>
                    <div className="col-sm-3">
                      <b>{nArr2[0].address}</b>
                    </div>
                    <div className="col-sm-7"></div>
                  </div>

                  <br />
                  <div className="row center-table" style={{ display: "" }}>
                    <table style={{ display: "" }}>
                      <tr>
                        <td
                          colSpan={5}
                          className="font-weight-bold text-primary"
                        >
                          Family Members
                        </td>
                      </tr>
                      <tr>
                        <th></th>
                        <th>Name</th>
                        <th>Relation</th>

                        <th>DOB</th>
                        <th>Gender</th>
                      </tr>
                      {nArr2 ? (
                        nArr2.map((item, index) => (
                          <>
                            <tr>
                              <td>
                                {item.gender === "M" ? (
                                  <>
                                    {" "}
                                    <i
                                      class="fas fa-male"
                                      style={{
                                        fontSize: "24px",
                                        padding: "5px",
                                      }}
                                    ></i>
                                  </>
                                ) : (
                                  <>
                                    <i
                                      class="fas fa-female"
                                      style={{
                                        fontSize: "24px",
                                        padding: "5px",
                                      }}
                                    ></i>
                                  </>
                                )}
                              </td>

                              <td>{item.memberName}</td>
                              <td>{item.relationName}</td>

                              <td>{item.dateOfBirth}</td>
                              <td>{item.gender}</td>
                              {/* {item.ekycStatus} */}
                            </tr>
                          </>
                        ))
                      ) : (
                        <>Nothing Any Selected Member</>
                      )}
                    </table>
                  </div>
                  <br />
                  {/* CARD ICONS MODULE */}
                  <div className="main p-bottom" style={{ display: "" }}>
                    {/* ******************   first row  ****************************/}
                    <div className="row">
                      <div className="col-sm-3 mresponsive">
                        {/* CARD BUTTON */}
                        <a href="#" onClick={() => editMemberDetails()}>
                          <div className="cardBody">
                            <div className="cardheader">
                              <div id="family-d"></div>
                              <i className="fas fa-users"></i>
                            </div>

                            <div className="cardcontainer">
                              <p>Family Details</p>
                            </div>
                          </div>
                        </a>
                        {/* END CARD BUTTON */}
                      </div>
                      <div className="col-sm-3 mresponsive">
                        {/* CARD BUTTON */}
                        <a href="#" onClick={() => editGenderDetails()}>
                          <div className="cardBody">
                            <div className="cardheader">
                              <div id="tick-gender"></div>
                              <i className="fas fa-mars"></i>
                              &nbsp;
                              <i className="fas fa-venus"></i>
                            </div>
                            <div className="cardcontainer">
                              <p>Gender</p>
                            </div>
                          </div>
                        </a>
                        {/* END CARD BUTTON */}
                      </div>

                      <div className="col-sm-3 mresponsive">
                        {/* CARD BUTTON */}
                        <a href="#" onClick={() => editDobDetails()}>
                          <div className="cardBody">
                            <div className="cardheader">
                              <div id="tick-dob"></div>
                              <i className="fas fa-birthday-cake"></i>
                            </div>
                            <div className="cardcontainer">
                              <p>DOB</p>
                            </div>
                          </div>
                        </a>
                        {/* END CARD BUTTON */}
                      </div>
                      <div className="col-sm-3 mresponsive">
                        {/* CARD BUTTON */}
                        <a href="#" onClick={() => editFRDetails()}>
                          <div className="cardBody">
                            <div className="cardheader">
                              <div id="tick-frel"></div>
                              <i className="fas fa-child"></i>
                            </div>
                            <div className="cardcontainer">
                              <p>Family Relation</p>
                            </div>
                          </div>
                        </a>
                        {/* END CARD BUTTON */}
                      </div>
                    </div>
                    {/* ******************   2nd row  ****************************/}
                    <div className="row">
                      <div className="col-sm-3 mresponsive">
                        {/* CARD BUTTON */}
                        <a href="#" onClick={() => editEducationDetails()}>
                          <div className="cardBody">
                            <div className="cardheader">
                              <div id="tick-educat"></div>
                              <i className="fas fa-book"></i>
                            </div>
                            <div className="cardcontainer">
                              <p>Education</p>
                            </div>
                          </div>
                        </a>
                        {/* END CARD BUTTON */}
                      </div>
                      <div className="col-sm-3 mresponsive">
                        {/* CARD BUTTON */}
                        <a href="#" onClick={() => editOccupationDetails()}>
                          <div className="cardBody">
                            <div className="cardheader">
                              <div id="tick-occup"></div>
                              <i className="fas fa-briefcase"></i>
                            </div>
                            <div className="cardcontainer">
                              <p>Occupation</p>
                            </div>
                          </div>
                        </a>
                        {/* END CARD BUTTON */}
                      </div>
                      <div className="col-sm-3 mresponsive">
                        <a href="#" onClick={() => editVerifyAdhaarDetails()}>
                          {/* CARD BUTTON */}
                          <div className="cardBody">
                            <div className="cardheader">
                              <div id="tick-veryadhaar"></div>
                              <i className="fa fa-address-card"></i>
                            </div>
                            <div className="cardcontainer">
                              <p>Verify Adhaar</p>
                            </div>
                          </div>
                          {/* END CARD BUTTON */}
                        </a>
                      </div>
                      <div className="col-sm-3 mresponsive">
                        <a href="#" onClick={() => editMobileno()}>
                          {/* CARD BUTTON */}
                          <div className="cardBody">
                            <div className="cardheader">
                              <div id="tick-phone"></div>
                              <i className="fas fa-mobile-alt"></i>
                            </div>
                            <div className="cardcontainer">
                              <p>Phone</p>
                            </div>
                          </div>
                          {/* END CARD BUTTON */}
                        </a>
                      </div>
                    </div>
                    {/* ******************   3rd row  ****************************/}
                    <div className="row p-bottom" style={{ display: "" }}>
                      <div className="col-sm-3 mresponsive">
                        <a href="#" onClick={() => editPropertyDetails()}>
                          {/* CARD BUTTON */}
                          <div class="cardBody">
                            <div class="cardheader">
                              <div id="tick-property"></div>
                              <i class="fas fa-building"></i>
                            </div>
                            <div class="cardcontainer">
                              <p>Property</p>
                            </div>
                          </div>
                          {/* END CARD BUTTON */}
                        </a>
                      </div>
                      <div className="col-sm-3 mresponsive">
                        <a href="#" onClick={() => editEmailid()}>
                          {/* CARD BUTTON */}
                          <div className="cardBody">
                            <div className="cardheader">
                              <div id="tick-email"></div>
                              <i className="fas fa-envelope"></i>
                            </div>
                            <div className="cardcontainer">
                              <p>Email</p>
                            </div>
                          </div>
                          {/* END CARD BUTTON */}
                        </a>
                      </div>
                    </div>
                    <div style={{textAlign:"center"}}>
                    <a href="#" class="btn btn-primary btn-icon-split btn-lg">
                      <span class="icon text-white-50">
                        <i class="fas fa-flag"></i>
                      </span>
                      <span class="text">Add Family</span>
                    </a>
                    </div>
                   
                  </div>
                </div>
              </div>
              {/* End Data Table*/}
            </div>
          </div>
          {/* <!-- Footer Section --> */}
          <Footer />
          {/* <!-- Footer Section End --> */}
          {/* <!-- End of Page Wrapper --> */}

          {/* <!-- Scroll to Top Button--> */}
          <a className="scroll-to-top rounded" href="#page-top">
            <i className="fas fa-angle-up"></i>
          </a>

          {/* <!-- Logout Modal--> */}
          <Logout />
          {/* <!-- Modals--> */}
          <Editmembers
            OnEditMemberDetails={nArr2}
            arrSelectedOptionsEc={selectedOptionsEc}
            arrSelectedOptionsRL={selectedOptionsRL}
            arrSelectedOptionsSC={selectedOptionsSC}
            arrSelectedOptionsRes={selectedOptionsRes}
            arrSelectedOptionsDist={selectedOptionsDist}
            arrSelectedOptionsMunci={selectedOptionsMunci}
            callCloseAndTickUpdate={(obj) => closeAndTickUpdate(obj)}
          />
          <Gender
            OnGenderDetails={nArr2}
            callCloseAndTickUpdate={(obj) => closeAndTickUpdate(obj)}
          />
          <Dob
            OnDoBDetails={nArr2}
            callCloseAndTickUpdate={(obj) => closeAndTickUpdate(obj)}
          />
          <Education
            OnEducationDetails={nArr2}
            callCloseAndTickUpdate={(obj) => closeAndTickUpdate(obj)}
          />
          <Familyrel
            OnFamilyrelDetails={nArr2}
            callCloseAndTickUpdate={(obj) => closeAndTickUpdate(obj)}
          />
          <Occupation
            OnOccupationDetails={nArr2}
            callCloseAndTickUpdate={(obj) => closeAndTickUpdate(obj)}
          />
          <Parivarlink
            OnParivarlinkDetails={nArr2}
            callCloseAndTickUpdate={(obj) => closeAndTickUpdate(obj)}
          />
          <Proprty
            OnProprtyDetails={nArr2}
            callCloseAndTickUpdate={(obj) => closeAndTickUpdate(obj)}
          />
          <Mobileno
            OnMobilenoDetails={nArr2}
            callCloseAndTickUpdate={(obj) => closeAndTickUpdate(obj)}
          />
          <Email
            OnEmailDetails={nArr2}
            callCloseAndTickUpdate={(obj) => closeAndTickUpdate(obj)}
          />
          <Verifyadhaar
            OnVerifyadhaarDetails={nArr2}
            callCloseAndTickUpdate={(obj) => closeAndTickUpdate(obj)}
          />
        </div>

        {/* <!-- Content-Wrapper End--> */}
      </div>
    </>
  );
};

export default SelectedMembers;
