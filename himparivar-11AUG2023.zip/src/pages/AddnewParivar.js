import React, { Component, useState, useEffect } from "react";
import Header from "../components/Header";
import HeaderBar from "../components/HeaderBar";
import LMenu from "../components/LMenu";
import Footer from "../components/Footer";
import Editshoplist from "../components/Models/Editshoplist";
import Logout from "../components/Logout";
import { Refinedata, FetchApiCall } from "../lib/Fetch";
import { WardMembersFetch } from "../lib/WardMembersFetch";
import { data } from "jquery";
import '../App.css';
import { useNavigate } from "react-router-dom";

const AddnewParivar = () => {


  const navigate = useNavigate();
 
  // if (loggedUser) {
  //   const loggedUserData = JSON.parse(loggedUser);
  // } else {
  //   window.location = "/";
  // }

  // Other class methods (if needed)
  const navLink=(props)=>{
    navigate(props);
  }

 


    
    // const [memberList, setMemberList] = useState();
    const loggedUser = JSON.parse(localStorage.getItem("loggedUser"));
    var authToken = loggedUser.data.token;
    //console.log(authToken);

    return (
      <>
        <div id="wrapper">
          {/* <!-- Left Menu Bar --> */}
          <LMenu />
          {/* <!-- Left Menu Bar End --> */}
          {/* <!-- Content Wrapper --> */}
          <div id="content-wrapper" className="d-flex flex-column">
            {/* <!-- Page Wrapper --> */}

            {/* <!-- Header Content --> */}
            <div id="content">
              {/* <!-- Begin Page Content --> */}
              {/* <!-- Head Search Bar --> */}
              <Header />
              {/* <!-- Head Search Bar End --> */}
              {/* <!-- Begin Page Content --> */}
              <div className="container-fluid">
                {/* <!-- Page Heading --> */}
                <HeaderBar titlePage={"Add Register"} />
                {/* <!-- End of Header Content --> */}

                {/* <!-- Start Middle Content --> */}
                <div class="row">
                  <div class="col">
                    <div class="card shadow mb-4">
                      <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary">
                          New Parivar
                        </h6>
                      </div>
                      <div class="card-body">
                        Please click here to add New Parivar alongwith Head of
                        Family details
                        <div class="d-flex flex-row">
                          <div class="p-2">
                          <a className="btn btn-light btn-icon-split" href="" onClick={() => navLink('/addfamily')}>
                            {/* <a href="/addfamily/fm:1" class="btn btn-light btn-icon-split"> */}
                              <span class="icon text-gray-600">
                                <i class="fas fa-arrow-right"></i>
                              </span>
                              <span class="text">Add New Parivar</span>
                            </a>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="col">
                    <div class="card shadow mb-4" style={{height:"194px"}}>
                      <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary ">
                          Add Member In Parivar
                        </h6>
                      </div>
                      <div class="card-body">
                        Please click here to add member(s) in the existing
                        Parivar.
                        <br/><br/>
                        <div class="d-flex flex-row">
                          <div class="p-2">
                            <a href="/addfamilyfm:2" class="btn btn-light btn-icon-split">
                              <span class="icon text-gray-600">
                                <i class="fas fa-arrow-right"></i>
                              </span>
                              <span class="text">Add New Family Member</span>
                            </a>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                {/* Add New Parivar */}

                {/* <!-- End Start Middle Content --> */}
              </div>
            </div>
            {/* <!-- Footer Section --> */}
            <Footer />
            {/* <!-- Footer Section End --> */}
            {/* <!-- End of Page Wrapper --> */}

            {/* <!-- Scroll to Top Button--> */}
            <a className="scroll-to-top rounded" href="#page-top">
              <i className="fas fa-angle-up"></i>
            </a>

            {/* <!-- Logout Modal--> */}
            <Logout />
            {/* <!-- Edit Shop Modal--> */}
            <Editshoplist datashop="deee" />
          </div>
          {/* <!-- Content-Wrapper End--> */}
        </div>
      </>
    );
  
}

export default AddnewParivar;
