import React, { Component, useState, useEffect } from "react";
import Header from "../components/Header";
import HeaderBar from "../components/HeaderBar";
import LMenu from "../components/LMenu";
import Footer from "../components/Footer";
import Editshoplist from "../components/Models/Editshoplist";
import Logout from "../components/Logout";
import { useParams } from "react-router-dom";
import { useNavigate } from "react-router-dom";
import "../../src/App.css";

const SelectedMembers = () => {
  const selectMembrs = localStorage.getItem("selectedMembers");
  const nArr = JSON.stringify(JSON.parse(selectMembrs));
  const nArr2 = JSON.parse(nArr);
  const [editing, setEditing] = useState(false);

  // const [textValues, setTextValues] = useState({
  //   value1: 'Initial Value 1',
  //   value2: 'Initial Value 2',
  // value3: 'Initial Value 3',
  // value4: 'Initial Value 4',
  // memberName: 'DEEE',
  //   // Add more text values as needed
  // });

  const [textValues, setTextValues] = useState(nArr2);

  const arrD1 = () => {
    console.log(textValues);
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setTextValues((prevValues) => ({
      ...prevValues,
      [name]: value,
    }));
  };

  const handleEditClick = () => {
    setEditing(true);
  };

  const handleSaveClick = () => {
    setEditing(false);
    // Perform any save/update logic here with the updated textValues
  };

  //console.log(nArr2);
  return (
    <>
      <div id="wrapper">
        {/* <!-- Left Menu Bar --> */}
        <LMenu />
        {/* <!-- Left Menu Bar End --> */}
        {/* <!-- Content Wrapper --> */}
        <div id="content-wrapper" className="d-flex flex-column">
          {/* <!-- Page Wrapper --> */}

          {/* <!-- Header Content --> */}
          <div id="content">
            {/* <!-- Begin Page Content --> */}
            {/* <!-- Head Search Bar --> */}
            <Header />
            {/* <!-- Head Search Bar End --> */}
            {/* <!-- Begin Page Content --> */}
            <div className="container-fluid">
              {/* <!-- Page Heading --> */}
              <HeaderBar titlePage={"Selected Parivar Members"} />
              {/* <!-- End of Header Content --> */}

              <div className="card shadow mb-4">
                <div className="card-header py-3 font-weight-bold text-primary">
                  <div className="row">
                    <div className="col">Selected Members For New Family</div>
                    <div className="col font-weight-bold text-primary cursor-pointer">
                      {editing ? (
                        <>
                          <a href="#" class="btn btn-secondary btn-icon-split">
                            <span class="icon text-white-50">
                              <i class="fas fa-arrow-right"></i>
                            </span>
                            <span class="text" onClick={handleSaveClick}>
                              Save Members
                            </span>
                          </a>
                        </>
                      ) : (
                        <>
                          {/* Display other text values */}
                          <a href="#" class="btn btn-light btn-icon-split">
                            <span class="icon text-gray-600">
                              <i class="fas fa-arrow-right"></i>
                            </span>
                            <span class="text" onClick={handleEditClick}>
                              Edit Members
                            </span>
                          </a>
                        </>
                      )}
                    </div>
                  </div>
                </div>

                {/* Data Table Start */}
                <div class="container">
                  <br />
                  <div className="row">
                    <ul className="no-bullets font-weight-bold text-primary">
                      <li>  Ration Card No :</li>
                      <li>   Address: </li>
                    </ul>
                  </div>
                  <br/><br/>
                  <table>
                    <tr>
                      <th></th>
                      <th>Adhaar Card No</th>
                      <th>Name</th>
                      <th>Relation</th>
                      <th>Block</th>
                      <th>DOB</th>
                      <th>Gender</th>
                      <th>Education</th>
                      <th>Occupation</th>
                      <th>eKYC Status</th>
                    </tr>
                    {nArr2 ? (
                    nArr2.map((item, index) => (
                      <>
                        
                       
                              
                      </>
                    ))
                  ) : (
                    <>Nothing Any Selected Member</>
                  )}

                  </table>
                  {nArr2 ? (
                    nArr2.map((item, index) => (
                      <>
                        <table className="rtable rtable--flip">
                          <thead>
                            <tr>
                              <th>Ration Card No</th>
                              <th>Adhaar Card No</th>
                              <th>Name</th>
                              <th>Card Type</th>
                              <th>Relation</th>
                              <th>Block</th>
                              <th>DOB</th>
                              <th>Gender</th>
                              <th>Cast Category</th>
                              <th>Address</th>
                              <th>Education</th>
                              <th>Occupation</th>
                              <th>eKYC Status</th>
                            </tr>
                          </thead>
                          <tbody>
                            {editing ? (
                              <>
                                {/* EDIT ROW */}
                                <tr>
                                  <td>{item.rationCardNumber}</td>

                                  <td>{item.aadhaarNumber}</td>
                                  <td>
                                    <input
                                      type="text"
                                      name={index + "-1-" + item.aadhaarNumber}
                                      value={item.memberName}
                                      onChange={handleInputChange}
                                    />
                                  </td>
                                  <td>
                                    <input
                                      type="text"
                                      name={index + "-2-" + item.aadhaarNumber}
                                      value={item.cardType}
                                      onChange={handleInputChange}
                                    />
                                  </td>
                                  <td>
                                    <input
                                      type="text"
                                      name={index + "-3-" + item.aadhaarNumber}
                                      value={item.relationName}
                                      onChange={handleInputChange}
                                    />
                                  </td>
                                  <td>
                                    <input
                                      type="text"
                                      name={index + "-4-" + item.aadhaarNumber}
                                      value={item.block}
                                      onChange={handleInputChange}
                                    />
                                  </td>
                                  <td>{item.dateOfBirth}</td>
                                  <td>
                                    <input
                                      type="text"
                                      name={index + "-5-" + item.aadhaarNumber}
                                      value={item.gender}
                                      onChange={handleInputChange}
                                    />
                                  </td>
                                  <td>{item.casteCategory}</td>
                                  <td>
                                    <input
                                      type="text"
                                      name={index + "-6-" + item.aadhaarNumber}
                                      value={item.address}
                                      onChange={handleInputChange}
                                    />
                                  </td>
                                  <td>
                                    <select>
                                      <option>Master</option>
                                      <option>Graduate</option>
                                      <option>Senior Secondry</option>
                                      <option>Matric</option>
                                      <option>No Educated</option>
                                    </select>
                                  </td>
                                  <td>
                                    <input
                                      type="text"
                                      name={index + "-7-" + item.aadhaarNumber}
                                      value="Occupation"
                                    />
                                  </td>
                                  <td>
                                    <input
                                      type="text"
                                      name={index + "-8-" + item.aadhaarNumber}
                                      value={item.ekycStatus}
                                      onChange={handleInputChange}
                                    />
                                  </td>
                                </tr>
                                {/* END EDIT ROW */}
                              </>
                            ) : (
                              <>
                                <tr>
                                  <td>
                                    <div className="row">
                                      <div className="col">
                                        {item.rationCardNumber}
                                      </div>
                                    </div>
                                  </td>

                                  <td>{item.aadhaarNumber}</td>
                                  <td>{item.memberName}</td>
                                  <td>{item.cardType}</td>
                                  <td>{item.relationName}</td>
                                  <td>{item.block}</td>
                                  <td>{item.dateOfBirth}</td>
                                  <td>{item.gender}</td>
                                  <td>{item.casteCategory}</td>
                                  <td>{item.address}</td>
                                  <td>Education</td>
                                  <td>Occupation</td>
                                  <td>
                                    <div className="row">
                                      <div className="col">
                                        {item.ekycStatus ===
                                        "eKYC not verified" ? (
                                          <a
                                            href="#"
                                            class="btn btn-info btn-icon-split"
                                          >
                                            <span class="icon text-white-50">
                                              <i class="fas fa-info-circle"></i>
                                            </span>
                                            <span class="text">Verify Ad</span>
                                          </a>
                                        ) : (
                                          <p>
                                            <div className="col">
                                              {item.ekycStatus}
                                            </div>
                                          </p>
                                        )}
                                      </div>
                                    </div>
                                  </td>
                                </tr>
                              </>
                            )}
                          </tbody>
                        </table>
                      </>
                    ))
                  ) : (
                    <>Nothing Any Selected Member</>
                  )}
                </div>
              </div>
              {/* End Data Table*/}
            </div>
          </div>
          {/* <!-- Footer Section --> */}
          <Footer />
          {/* <!-- Footer Section End --> */}
          {/* <!-- End of Page Wrapper --> */}

          {/* <!-- Scroll to Top Button--> */}
          <a className="scroll-to-top rounded" href="#page-top">
            <i className="fas fa-angle-up"></i>
          </a>

          {/* <!-- Logout Modal--> */}
          <Logout />
          {/* <!-- Edit Shop Modal--> */}
          <Editshoplist datashop="deee" />
        </div>
        {/* <!-- Content-Wrapper End--> */}
      </div>
    </>
  );
};

export default SelectedMembers;
